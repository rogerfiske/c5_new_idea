"""
TRUE Holdout Test on Last 100 Events - OPTIMIZED FOR RUNPOD

This script performs a TRUE holdout test where:
1. For each test event N, train on events 1 to N-1 only
2. Predict event N without seeing its actual results
3. Validate predictions against actual results

OPTIMIZATIONS:
- Parallel model training (4 models in parallel using 4 processes)
- Each model uses 4 LightGBM threads (16 vCPUs total)
- Checkpoint after each event (resume if interrupted)
- Command-line args for flexible testing
- Memory monitoring
- Comprehensive timing metrics (pure compute time vs wall clock time)

Hardware Target: RunPod 16 vCPU, 32GB RAM, 5+ GHz

Usage:
    # Full 100 events
    python production/true_holdout_test_100_optimized.py

    # Test on subset (e.g., last 5 events)
    python production/true_holdout_test_100_optimized.py --num-events 5

    # Resume from checkpoint
    python production/true_holdout_test_100_optimized.py --resume

Author: BMad Dev Agent (James)
Date: 2025-10-28
"""

import sys
from pathlib import Path
import pandas as pd
import numpy as np
import json
import argparse
from datetime import datetime
from tqdm import tqdm
from multiprocessing import Pool, cpu_count
import psutil
import os
import time

# Add project root to path
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from src.imputation.amplitude_embedding import AmplitudeEmbedding
from src.imputation.angle_encoding import AngleEncoding
from src.imputation.graph_cycle_encoding import GraphCycleEncoding
from src.imputation.density_matrix import DensityMatrixEmbedding
from src.modeling.rankers.lgbm_ranker_position_aware import LGBMRankerPositionAware


def get_memory_usage():
    """Get current memory usage in GB."""
    process = psutil.Process(os.getpid())
    return process.memory_info().rss / 1024 / 1024 / 1024


def load_raw_data(csv_path: Path) -> pd.DataFrame:
    """Load raw quantum state data."""
    print(f"Loading raw data: {csv_path}")
    df = pd.read_csv(csv_path)
    print(f"  Total events: {len(df)}")
    print(f"  Event ID range: {df['event-ID'].min()} to {df['event-ID'].max()}")
    print(f"  Memory: {get_memory_usage():.2f} GB")
    return df


def get_imputer_config(method_name: str) -> dict:
    """Get imputer configuration for a specific method."""
    configs = {
        'amplitude': {
            'class': AmplitudeEmbedding,
            'kwargs': {
                'name': 'amplitude_embedding',
                'normalization': 'uniform',
                'include_probability_features': True,
                'include_proximity_features': True
            }
        },
        'angle_encoding': {
            'class': AngleEncoding,
            'kwargs': {
                'name': 'angle_encoding',
                'include_proximity_features': True
            }
        },
        'graph_cycle': {
            'class': GraphCycleEncoding,
            'kwargs': {
                'name': 'graph_cycle_encoding',
                'n_harmonics': 20,
                'include_proximity_features': True
            }
        },
        'density_matrix': {
            'class': DensityMatrixEmbedding,
            'kwargs': {
                'name': 'density_matrix_optimized',
                'include_proximity_features': True
            }
        }
    }
    return configs[method_name]


def train_and_predict_single_method(args):
    """
    Train and predict for a single method (designed for parallel execution).

    Args:
        args: Tuple of (method_name, raw_data_path, train_event_ids, test_event_id, k)

    Returns:
        Tuple of (method_name, predictions_list, timing_breakdown, memory_gb)
    """
    method_name, raw_data_path, train_event_ids, test_event_id, k = args

    timing = {}
    start_time = time.time()

    # Load data
    load_start = time.time()
    raw_data = pd.read_csv(raw_data_path)
    train_data = raw_data[raw_data['event-ID'].isin(train_event_ids)].copy()
    test_data = raw_data[raw_data['event-ID'] == test_event_id].copy()
    timing['data_load'] = time.time() - load_start

    # Initialize and fit imputer
    impute_start = time.time()
    imputer_config = get_imputer_config(method_name)
    imputer = imputer_config['class'](**imputer_config['kwargs'])
    imputer.fit(train_data)
    timing['imputer_fit'] = time.time() - impute_start

    # Transform data
    transform_start = time.time()
    train_features = imputer.transform(train_data)
    test_features = imputer.transform(test_data)
    timing['imputer_transform'] = time.time() - transform_start

    # Prepare training data
    prep_start = time.time()
    feature_names = [f'feat_{i}' for i in range(train_features.shape[1])]
    train_df = pd.DataFrame(train_features, columns=feature_names)
    train_df.insert(0, 'event-ID', train_data['event-ID'].values)

    # Extract winning positions from QV columns and populate q_* columns
    for idx in range(len(train_data)):
        winning_positions = [i for i in range(1, 40) if train_data.iloc[idx][f'QV_{i}'] == 1]
        for q_idx in range(5):
            if q_idx < len(winning_positions):
                train_df.loc[idx, f'q_{q_idx+1}'] = winning_positions[q_idx]
            else:
                train_df.loc[idx, f'q_{q_idx+1}'] = 0

    # Add QV columns (for compatibility, but not used in training)
    for i in range(1, 40):
        train_df[f'QV_{i}'] = train_data[f'QV_{i}'].values
    timing['data_prep'] = time.time() - prep_start

    # Train model with 4 threads
    train_start = time.time()
    model = LGBMRankerPositionAware(
        params={
            'n_estimators': 100,
            'learning_rate': 0.1,
            'max_depth': 6,
            'num_leaves': 31,
            'min_child_samples': 20,
            'n_jobs': 4  # 4 threads per model
        },
        imputation_method=method_name  # KEY FIX: Pass method name for position-specific features
    )
    model.fit(train_df)
    timing['model_train'] = time.time() - train_start

    # Prepare test data and predict
    predict_start = time.time()
    test_df = pd.DataFrame(test_features, columns=feature_names)
    test_df.insert(0, 'event-ID', test_data['event-ID'].values)

    # q_* columns not needed for prediction (only for training)
    for q_idx in range(5):
        test_df[f'q_{q_idx+1}'] = 0

    # QV columns set to 0 for test (we don't know the answer yet)
    for i in range(1, 40):
        test_df[f'QV_{i}'] = 0

    top_k = model.predict_top_k(test_df, k=k)[0]
    timing['model_predict'] = time.time() - predict_start

    timing['total'] = time.time() - start_time
    memory_gb = get_memory_usage()

    return (method_name, top_k.tolist(), timing, memory_gb)


def predict_single_event_parallel(
    raw_data: pd.DataFrame,
    raw_data_path: Path,
    test_event_id: int,
    k: int = 20,
    n_processes: int = 4
) -> dict:
    """
    Predict a single event using TRUE holdout with parallel model training.

    Args:
        raw_data: Full dataset (for getting actual winners)
        raw_data_path: Path to CSV (for child processes)
        test_event_id: Event to predict
        k: Number of top predictions
        n_processes: Number of parallel processes (should be 4 for 4 models)

    Returns:
        Dictionary with predictions and actual results
    """
    event_start = time.time()

    # Get train event IDs
    train_event_ids = list(raw_data[raw_data['event-ID'] < test_event_id]['event-ID'])

    # Get actual winners
    test_data = raw_data[raw_data['event-ID'] == test_event_id]
    if len(test_data) == 0:
        raise ValueError(f"Event {test_event_id} not found")

    qv_cols = [f'QV_{i}' for i in range(1, 40)]
    actual_winners = list(np.where(test_data[qv_cols].values[0] == 1)[0] + 1)

    results = {
        'event_id': test_event_id,
        'actual_winners': actual_winners,
        'individual_predictions': {},
        'training_size': len(train_event_ids),
        'timing_breakdown': {},
        'memory_usage': {}
    }

    # Prepare args for parallel execution
    methods = ['amplitude', 'angle_encoding', 'graph_cycle', 'density_matrix']
    parallel_args = [
        (method, raw_data_path, train_event_ids, test_event_id, k)
        for method in methods
    ]

    # Train all 4 models in parallel
    parallel_start = time.time()
    with Pool(processes=n_processes) as pool:
        parallel_results = pool.map(train_and_predict_single_method, parallel_args)
    parallel_time = time.time() - parallel_start

    # Collect results
    for method_name, predictions, timing, memory_gb in parallel_results:
        results['individual_predictions'][method_name] = predictions
        results['timing_breakdown'][method_name] = timing
        results['memory_usage'][method_name] = memory_gb

    # Ensemble prediction
    ensemble_start = time.time()
    all_predictions = []
    for method_predictions in results['individual_predictions'].values():
        all_predictions.extend(method_predictions)

    from collections import Counter
    vote_counts = Counter(all_predictions)
    ensemble_top_k = [pos for pos, _ in vote_counts.most_common(k)]
    results['ensemble_prediction'] = ensemble_top_k
    ensemble_time = time.time() - ensemble_start

    # Overall timing
    results['timing_summary'] = {
        'parallel_execution': parallel_time,
        'ensemble_voting': ensemble_time,
        'total_event': time.time() - event_start
    }

    return results


def evaluate_predictions(results: dict) -> dict:
    """Evaluate predictions against actual winners."""
    actual = set(results['actual_winners'])
    evaluation = {}

    for method_name, predictions in results['individual_predictions'].items():
        found = set(predictions[:20]) & actual
        recall = len(found) / len(actual)
        wrong_count = len(actual) - len(found)

        evaluation[method_name] = {
            'recall_at_20': recall,
            'found': sorted(list(found)),
            'missed': sorted(list(actual - found)),
            'wrong_count': wrong_count
        }

    # Ensemble evaluation
    ensemble_found = set(results['ensemble_prediction'][:20]) & actual
    ensemble_recall = len(ensemble_found) / len(actual)
    ensemble_wrong = len(actual) - len(ensemble_found)

    evaluation['ensemble'] = {
        'recall_at_20': ensemble_recall,
        'found': sorted(list(ensemble_found)),
        'missed': sorted(list(actual - ensemble_found)),
        'wrong_count': ensemble_wrong
    }

    return evaluation


def save_checkpoint(output_dir: Path, all_evaluations: list, checkpoint_event: int):
    """Save checkpoint after processing an event."""
    checkpoint_path = output_dir / 'checkpoint.json'

    # Convert numpy types to Python types for JSON serialization
    def convert_numpy_types(obj):
        if isinstance(obj, np.integer):
            return int(obj)
        elif isinstance(obj, np.floating):
            return float(obj)
        elif isinstance(obj, np.ndarray):
            return obj.tolist()
        elif isinstance(obj, dict):
            return {k: convert_numpy_types(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [convert_numpy_types(item) for item in obj]
        return obj

    checkpoint_data = {
        'last_completed_event': int(checkpoint_event),
        'num_events_completed': len(all_evaluations),
        'timestamp': datetime.now().isoformat(),
        'evaluations': convert_numpy_types(all_evaluations)
    }
    with open(checkpoint_path, 'w') as f:
        json.dump(checkpoint_data, f, indent=2)


def load_checkpoint(output_dir: Path) -> dict:
    """Load checkpoint if it exists."""
    checkpoint_path = output_dir / 'checkpoint.json'
    if checkpoint_path.exists():
        with open(checkpoint_path, 'r') as f:
            return json.load(f)
    return None


def main():
    """Run TRUE holdout test with parallel execution and checkpointing."""
    parser = argparse.ArgumentParser(description='TRUE Holdout Test - Optimized')
    parser.add_argument('--num-events', type=int, default=100,
                        help='Number of events to test (default: 100)')
    parser.add_argument('--start-event', type=int, default=None,
                        help='Starting event ID (default: auto-calculate from num-events)')
    parser.add_argument('--resume', action='store_true',
                        help='Resume from checkpoint if available')
    parser.add_argument('--n-processes', type=int, default=4,
                        help='Number of parallel processes (default: 4)')
    args = parser.parse_args()

    # COMPUTE TIME TRACKING START
    script_start_time = time.time()
    script_start_datetime = datetime.now()

    print("="*80)
    print("TRUE HOLDOUT TEST - PARALLEL OPTIMIZED")
    print("="*80)
    print(f"\n[TIME] Script Started: {script_start_datetime.strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"\nConfiguration:")
    print(f"  Parallel processes: {args.n_processes}")
    print(f"  Threads per model: 4")
    print(f"  Total vCPUs used: {args.n_processes * 4}")
    print(f"  Available CPUs: {cpu_count()}")
    print(f"  Memory available: {psutil.virtual_memory().total / 1024 / 1024 / 1024:.1f} GB")
    print(f"  Memory current: {get_memory_usage():.2f} GB\n")

    # Load data
    data_load_start = time.time()
    csv_path = project_root / 'data' / 'raw' / 'c5_Matrix.csv'
    raw_data = load_raw_data(csv_path)
    data_load_time = time.time() - data_load_start

    # Determine test range
    max_event = raw_data['event-ID'].max()
    if args.start_event:
        test_start = args.start_event
    else:
        test_start = max_event - args.num_events + 1

    test_events = list(range(test_start, test_start + args.num_events))

    print(f"\nTest Configuration:")
    print(f"  Test range: Events {test_start} to {test_start + args.num_events - 1}")
    print(f"  Total events: {args.num_events}")
    print(f"  Training: Events 1 to N-1 for each test event N\n")

    # Setup output directory
    output_dir = project_root / 'production' / 'reports' / 'true_holdout_100'
    output_dir.mkdir(parents=True, exist_ok=True)

    # Check for checkpoint
    all_evaluations = []
    start_index = 0
    checkpoint_load_time = 0

    if args.resume:
        checkpoint_load_start = time.time()
        checkpoint = load_checkpoint(output_dir)
        checkpoint_load_time = time.time() - checkpoint_load_start
        if checkpoint:
            print(f"[CHECKPOINT] Resuming from event {checkpoint['last_completed_event']}")
            print(f"             {checkpoint['num_events_completed']} events already completed\n")
            all_evaluations = checkpoint['evaluations']
            last_completed = checkpoint['last_completed_event']
            start_index = test_events.index(last_completed) + 1 if last_completed in test_events else 0

    # PURE COMPUTE TIME TRACKING START (after setup)
    compute_start_time = time.time()

    # Run test on each event
    print("Running TRUE holdout predictions with parallel model training...\n")

    for idx in range(start_index, len(test_events)):
        event_id = test_events[idx]

        print(f"\n{'='*80}")
        print(f"Event {event_id} ({idx+1}/{len(test_events)})")
        print(f"{'='*80}")

        try:
            # Predict with parallel execution
            results = predict_single_event_parallel(
                raw_data, csv_path, event_id, k=20, n_processes=args.n_processes
            )

            # Evaluate
            evaluation = evaluate_predictions(results)

            # Add all timing and metadata
            evaluation_record = {
                'event_id': event_id,
                'actual_winners': results['actual_winners'],
                'training_size': results['training_size'],
                'timing_breakdown': results['timing_breakdown'],
                'timing_summary': results['timing_summary'],
                'memory_usage': results['memory_usage'],
                **evaluation
            }

            all_evaluations.append(evaluation_record)

            # Print summary
            print(f"\n  Event Duration: {results['timing_summary']['total_event']:.1f}s")
            print(f"  Parallel Exec:  {results['timing_summary']['parallel_execution']:.1f}s")
            print(f"  Model Training Times:")
            for method, timing in results['timing_breakdown'].items():
                print(f"    {method}: train={timing['model_train']:.1f}s, total={timing['total']:.1f}s")
            print(f"  Memory Peak: {max(results['memory_usage'].values()):.2f} GB")
            print(f"  Recalls: " + ", ".join([
                f"{k}: {v['recall_at_20']*100:.0f}%"
                for k, v in evaluation.items()
            ]))

            # Save checkpoint
            save_checkpoint(output_dir, all_evaluations, event_id)
            print(f"  [CHECKPOINT] Saved")

        except Exception as e:
            print(f"\n[ERROR] Failed on event {event_id}: {e}")
            import traceback
            traceback.print_exc()
            continue

    # COMPUTE TIME TRACKING END
    compute_end_time = time.time()
    pure_compute_time = compute_end_time - compute_start_time

    # SCRIPT TIME TRACKING END
    script_end_time = time.time()
    script_end_datetime = datetime.now()
    total_script_time = script_end_time - script_start_time

    # Calculate aggregate statistics
    print("\n" + "="*80)
    print("AGGREGATE RESULTS")
    print("="*80)

    # Per-model statistics
    model_stats = {
        'amplitude': [],
        'angle_encoding': [],
        'graph_cycle': [],
        'density_matrix': [],
        'ensemble': []
    }

    for eval_result in all_evaluations:
        for model_name in model_stats.keys():
            if model_name in eval_result:
                model_stats[model_name].append(eval_result[model_name]['recall_at_20'])

    print(f"\nRecall@20 Statistics ({len(all_evaluations)} events):\n")
    print(f"{'Model':<20} {'Mean':<10} {'Std':<10} {'Min':<10} {'Max':<10}")
    print("-" * 60)

    summary = {}
    for model_name, recalls in model_stats.items():
        if recalls:
            mean_recall = np.mean(recalls) * 100
            std_recall = np.std(recalls) * 100
            min_recall = np.min(recalls) * 100
            max_recall = np.max(recalls) * 100

            print(f"{model_name.replace('_', ' ').title():<20} {mean_recall:>6.1f}%   "
                  f"{std_recall:>6.1f}%   {min_recall:>6.1f}%   {max_recall:>6.1f}%")

            summary[model_name] = {
                'mean_recall': mean_recall,
                'std_recall': std_recall,
                'min_recall': min_recall,
                'max_recall': max_recall
            }

    # Find best model
    best_model = max(summary.items(), key=lambda x: x[1]['mean_recall'])
    print(f"\n[BEST] Best Model: {best_model[0].replace('_', ' ').title()} "
          f"({best_model[1]['mean_recall']:.1f}% avg recall)")

    # Comprehensive timing breakdown
    per_event_times = [e['timing_summary']['total_event'] for e in all_evaluations]
    parallel_times = [e['timing_summary']['parallel_execution'] for e in all_evaluations]

    print(f"\n" + "="*80)
    print("TIMING ANALYSIS (Pure Compute Time)")
    print("="*80)
    print(f"\n[COMPUTE] PURE COMPUTE TIME: {pure_compute_time/60:.2f} minutes ({pure_compute_time:.1f}s)")
    print(f"   (Excludes manual setup, only actual computation)")
    print(f"\nPer-Event Statistics:")
    print(f"  Average per event: {np.mean(per_event_times):.1f}s")
    print(f"  Min/Max per event: {np.min(per_event_times):.1f}s / {np.max(per_event_times):.1f}s")
    print(f"  Total events time: {sum(per_event_times)/60:.1f} minutes")
    print(f"\nParallel Execution Statistics:")
    print(f"  Average parallel time: {np.mean(parallel_times):.1f}s")
    print(f"  Min/Max parallel time: {np.min(parallel_times):.1f}s / {np.max(parallel_times):.1f}s")
    print(f"\nScript Overhead:")
    print(f"  Data loading: {data_load_time:.1f}s")
    print(f"  Checkpoint load: {checkpoint_load_time:.1f}s")
    print(f"  Other overhead: {(total_script_time - pure_compute_time - data_load_time - checkpoint_load_time):.1f}s")
    print(f"\n[TOTAL] TOTAL SCRIPT TIME: {total_script_time/60:.2f} minutes")
    print(f"   (Includes all overhead + compute)")
    print(f"\n[TIME] Started:  {script_start_datetime.strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"[TIME] Finished: {script_end_datetime.strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"[TIME] Duration: {script_end_datetime - script_start_datetime}")

    # Extrapolation
    if len(all_evaluations) < 100:
        estimated_full_100 = (pure_compute_time / len(all_evaluations)) * 100
        print(f"\n[ESTIMATE] Full 100 Events: {estimated_full_100/60:.2f} minutes (pure compute)")

    # Save results with comprehensive timing
    with open(output_dir / 'detailed_results.json', 'w') as f:
        json.dump({
            'test_range': f'{test_start}-{test_start + args.num_events - 1}',
            'num_events': len(all_evaluations),
            'results': all_evaluations,
            'summary': summary,
            'best_model': best_model[0],
            'configuration': {
                'n_processes': args.n_processes,
                'threads_per_model': 4,
                'total_vcpus': args.n_processes * 4,
                'hardware': f"{cpu_count()} CPUs, {psutil.virtual_memory().total / 1024 / 1024 / 1024:.1f} GB RAM"
            },
            'timing_metrics': {
                'script_start': script_start_datetime.isoformat(),
                'script_end': script_end_datetime.isoformat(),
                'pure_compute_time_seconds': pure_compute_time,
                'pure_compute_time_minutes': pure_compute_time / 60,
                'total_script_time_seconds': total_script_time,
                'total_script_time_minutes': total_script_time / 60,
                'data_load_time_seconds': data_load_time,
                'checkpoint_load_time_seconds': checkpoint_load_time,
                'average_per_event_seconds': np.mean(per_event_times),
                'average_parallel_time_seconds': np.mean(parallel_times),
                'estimated_full_100_events_minutes': (pure_compute_time / len(all_evaluations) * 100) / 60 if len(all_evaluations) > 0 else None
            }
        }, f, indent=2)

    # Save summary report
    with open(output_dir / 'summary_report.txt', 'w') as f:
        f.write("TRUE HOLDOUT TEST - PARALLEL OPTIMIZED\n")
        f.write("="*80 + "\n\n")
        f.write(f"Test Range: {test_start} to {test_start + args.num_events - 1}\n")
        f.write(f"Events Tested: {len(all_evaluations)}\n\n")
        f.write("Recall@20 Statistics:\n\n")
        f.write(f"{'Model':<20} {'Mean':<10} {'Std':<10} {'Min':<10} {'Max':<10}\n")
        f.write("-" * 60 + "\n")
        for model_name, stats in summary.items():
            f.write(f"{model_name.replace('_', ' ').title():<20} "
                   f"{stats['mean_recall']:>6.1f}%   "
                   f"{stats['std_recall']:>6.1f}%   "
                   f"{stats['min_recall']:>6.1f}%   "
                   f"{stats['max_recall']:>6.1f}%\n")
        f.write(f"\nBest Model: {best_model[0].replace('_', ' ').title()} "
               f"({best_model[1]['mean_recall']:.1f}% avg recall)\n")
        f.write(f"\n{'='*80}\n")
        f.write("TIMING METRICS\n")
        f.write(f"{'='*80}\n\n")
        f.write(f"PURE COMPUTE TIME: {pure_compute_time/60:.2f} minutes\n")
        f.write(f"  (Excludes manual setup/fumbling, only actual computation)\n\n")
        f.write(f"Per-Event Statistics:\n")
        f.write(f"  Average per event: {np.mean(per_event_times):.1f}s\n")
        f.write(f"  Min/Max per event: {np.min(per_event_times):.1f}s / {np.max(per_event_times):.1f}s\n\n")
        f.write(f"TOTAL SCRIPT TIME: {total_script_time/60:.2f} minutes\n")
        f.write(f"  (Includes all overhead + compute)\n\n")
        f.write(f"Started:  {script_start_datetime.strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"Finished: {script_end_datetime.strftime('%Y-%m-%d %H:%M:%S')}\n")
        if len(all_evaluations) < 100:
            f.write(f"\nEstimated Full 100 Events: {(pure_compute_time / len(all_evaluations) * 100)/60:.2f} minutes\n")

    print(f"\n✅ Results saved to: {output_dir}")
    print(f"   - detailed_results.json (includes comprehensive timing metrics)")
    print(f"   - summary_report.txt")
    print(f"   - checkpoint.json")
    print("\n" + "="*80)


if __name__ == '__main__':
    main()
