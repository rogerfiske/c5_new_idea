"""
Proximity-Based Quantum Features

This module implements quantum-inspired features that model how winning positions
(QV=1) influence ALL positions (including non-winners QV=0) through spatial
relationships on the C₃₉ cyclic ring.

Physical Motivation:
-------------------
In quantum mechanics, occupied quantum states influence unoccupied states through:
- Interference: Wave function overlap creates patterns
- Tunneling: Probability amplitude leaks through spatial barriers
- Field Effects: Occupied states create fields affecting all positions
- Entanglement: Correlations extend beyond direct occupation

Current quantum imputation only processes winning positions in isolation,
ignoring their influence on non-winning positions. This module addresses that gap.

Author: BMad Dev Agent (James)
Date: 2025-10-23
Story: Quantum Imputation Enhancement - Proximity Features (Phase 1)
"""

import numpy as np
from typing import List, Tuple


class ProximityFeatures:
    """
    Calculates proximity-based quantum features for all 39 positions.

    This class implements four types of proximity features that capture how
    winning positions (QV=1) influence all positions through quantum effects:

    1. Circular Distance: Minimum distance to nearest winner
    2. Tunneling Influence: Exponential decay from all winners
    3. Interference Intensity: Quantum wave interference patterns
    4. Local Density: Winner count in circular windows
    """

    def __init__(self, N: int = 39):
        """
        Initialize proximity feature calculator.

        Args:
            N: Ring size (default 39 for C₃₉ cyclic group)
        """
        self.N = N

    @staticmethod
    def circular_distance(pos_i: int, pos_j: int, N: int = 39) -> int:
        """
        Calculate minimum circular distance on C_N ring.

        On a cyclic ring, distance can be measured both clockwise and
        counterclockwise. This returns the shorter of the two.

        Args:
            pos_i: First position (1-indexed, range 1-N)
            pos_j: Second position (1-indexed, range 1-N)
            N: Ring size (default 39)

        Returns:
            Minimum circular distance (0 to N//2)

        Examples:
            >>> ProximityFeatures.circular_distance(1, 3, N=39)
            2
            >>> ProximityFeatures.circular_distance(1, 39, N=39)
            1
            >>> ProximityFeatures.circular_distance(1, 20, N=39)
            19
        """
        # Convert to 0-indexed
        i = pos_i - 1
        j = pos_j - 1

        # Calculate both directions
        dist_clockwise = abs(i - j)
        dist_counter = N - abs(i - j)

        return min(dist_clockwise, dist_counter)

    def compute_min_distance_features(self, qv_vector: np.ndarray) -> np.ndarray:
        """
        Compute minimum distance to nearest winner for each position.

        For each of the 39 positions, calculates the circular distance to
        the closest winning position. Winners have distance 0 to themselves.

        Physical Interpretation:
        - Value 0: Position is a winner
        - Value 1-3: Very close to winner (strong influence)
        - Value 4-10: Moderate distance (medium influence)
        - Value 11-19: Far from all winners (weak influence)

        Args:
            qv_vector: Binary vector (39,) where 1 = winner, 0 = non-winner

        Returns:
            min_distances: Array (39,) with minimum distance for each position
        """
        winning_positions = np.where(qv_vector == 1)[0] + 1  # Convert to 1-indexed

        min_distances = np.zeros(39)
        for pos_i in range(1, 40):
            if pos_i in winning_positions:
                # Winner positions have distance 0 to themselves
                min_distances[pos_i - 1] = 0
            else:
                # Non-winner: find minimum distance to any winner
                distances = [self.circular_distance(pos_i, w, N=self.N)
                           for w in winning_positions]
                min_distances[pos_i - 1] = min(distances)

        return min_distances

    @staticmethod
    def tunneling_probability(distance: float, decay_factor: float = 0.3) -> float:
        """
        Calculate quantum tunneling probability with exponential decay.

        In quantum mechanics, tunneling probability through a barrier
        decays exponentially with distance:
            P(x) = exp(-κx)
        where κ is the decay constant.

        Args:
            distance: Circular distance to winner
            decay_factor: Decay constant (higher = faster decay)

        Returns:
            Tunneling probability (0-1)

        Examples:
            >>> ProximityFeatures.tunneling_probability(0, 0.3)
            1.0
            >>> round(ProximityFeatures.tunneling_probability(1, 0.3), 3)
            0.741
            >>> round(ProximityFeatures.tunneling_probability(5, 0.3), 3)
            0.223
        """
        return np.exp(-decay_factor * distance)

    def compute_tunneling_features(
        self,
        qv_vector: np.ndarray,
        decay_factor: float = 0.3
    ) -> np.ndarray:
        """
        Compute quantum tunneling influence for each position.

        For each position, sums the exponentially-decaying influence from
        ALL winning positions. This models how quantum probability amplitude
        "tunnels" from winners to nearby positions.

        Physical Interpretation:
        - Winners: Maximum influence (5.0, since 5 winners × 1.0 each)
        - Adjacent non-winners (dist=1): High influence (~3.7 with decay=0.3)
        - Medium distance (dist=5): Moderate influence (~1.1)
        - Far distance (dist=15): Low influence (~0.05)

        Args:
            qv_vector: Binary vector (39,)
            decay_factor: Exponential decay rate (default 0.3)

        Returns:
            tunnel_influence: Array (39,) with cumulative influence
        """
        winning_positions = np.where(qv_vector == 1)[0] + 1  # 1-indexed

        tunnel_influence = np.zeros(39)
        for pos_i in range(1, 40):
            # Sum influence from all winners
            total_influence = 0.0
            for w in winning_positions:
                dist = self.circular_distance(pos_i, w, N=self.N)
                influence = self.tunneling_probability(dist, decay_factor)
                total_influence += influence

            tunnel_influence[pos_i - 1] = total_influence

        return tunnel_influence

    def compute_interference_features(self, qv_vector: np.ndarray) -> np.ndarray:
        """
        Compute quantum interference intensity for each position.

        In quantum mechanics, amplitudes add as complex numbers:
            ψ_total = Σⱼ ψⱼ exp(iφⱼ)

        Intensity (measurement probability):
            I = |ψ_total|² = |Σⱼ ψⱼ exp(iφⱼ)|²

        This models constructive/destructive interference patterns from
        the superposition of all winning positions.

        Physical Interpretation:
        - High intensity (>0.8): Constructive interference - waves add coherently
        - Medium intensity (0.4-0.8): Partial interference
        - Low intensity (<0.4): Destructive interference - waves cancel

        Hypothesis: Positions with high interference intensity in event N
        may be more likely to win in event N+1 (quantum "hot spots").

        Args:
            qv_vector: Binary vector (39,)

        Returns:
            interference_intensity: Array (39,) with intensity values
        """
        winning_positions = np.where(qv_vector == 1)[0] + 1  # 1-indexed

        # Equal amplitudes for all winners (uniform superposition)
        # Normalized: 5 × amplitude² = 1
        amplitude = 1.0 / np.sqrt(5)

        intensities = np.zeros(39)
        for pos_i in range(1, 40):
            # Phase determined by circular distance
            # Full cycle (2π) over ring circumference (39)
            real_part = 0.0
            imag_part = 0.0

            for w in winning_positions:
                dist = self.circular_distance(pos_i, w, N=self.N)
                phase = 2 * np.pi * dist / self.N

                # Complex amplitude: ψ = A × exp(iφ)
                real_part += amplitude * np.cos(phase)
                imag_part += amplitude * np.sin(phase)

            # Intensity: |ψ|² = (Re)² + (Im)²
            intensity = real_part**2 + imag_part**2
            intensities[pos_i - 1] = intensity

        return intensities

    def compute_local_density_features(
        self,
        qv_vector: np.ndarray,
        windows: List[int] = [3, 5, 7]
    ) -> np.ndarray:
        """
        Compute local density at multiple window sizes for each position.

        Counts the number of winners within a circular window around each
        position, normalized by total winner count (5).

        Physical Interpretation:
        - Window=3: Immediate neighborhood (distances 0-3)
        - Window=5: Local region (distances 0-5)
        - Window=7: Extended region (distances 0-7)

        Values:
        - High density (0.6-1.0): Position is in a cluster of winners
        - Low density (0-0.2): Position is isolated from winners

        Hypothesis: Positions in high-density regions may attract future
        winners (clustering phenomenon).

        Args:
            qv_vector: Binary vector (39,)
            windows: List of window radii (default [3, 5, 7])

        Returns:
            densities: Array (39, len(windows)) with density at each window size
        """
        winning_positions = np.where(qv_vector == 1)[0] + 1  # 1-indexed
        num_winners = len(winning_positions)

        densities = np.zeros((39, len(windows)))

        for pos_i in range(1, 40):
            for w_idx, window in enumerate(windows):
                # Count winners within window
                neighbors_in_window = [
                    w for w in winning_positions
                    if self.circular_distance(pos_i, w, N=self.N) <= window
                ]

                # Normalize by total number of winners
                density = len(neighbors_in_window) / num_winners
                densities[pos_i - 1, w_idx] = density

        return densities

    def compute_all_features(
        self,
        qv_vector: np.ndarray,
        decay_factor: float = 0.3,
        windows: List[int] = [3, 5, 7],
        include_interference: bool = False
    ) -> Tuple[np.ndarray, List[str]]:
        """
        Compute all proximity-based features for a single event.

        Combines three feature types (interference excluded by default due to low importance):
        1. Circular distance (39 features)
        2. Tunneling influence (39 features)
        3. Local density (39 × len(windows) features)

        Optional:
        4. Interference intensity (39 features) - excluded by default (0.11% importance)

        Total: 195 features (with default windows=[3,5,7] and include_interference=False)

        Args:
            qv_vector: Binary vector (39,) indicating winners
            decay_factor: Tunneling decay rate (default 0.3)
            windows: Window sizes for local density (default [3,5,7])
            include_interference: Include interference features (default False, 0.11% importance)

        Returns:
            features: Array (195,) or (234,) with proximity features
            feature_names: List of feature names for DataFrame columns
        """
        # Compute each feature set
        min_dist = self.compute_min_distance_features(qv_vector)
        tunnel = self.compute_tunneling_features(qv_vector, decay_factor)
        density = self.compute_local_density_features(qv_vector, windows)

        # Build feature list
        features_to_concat = [
            min_dist,           # 39 features
            tunnel,             # 39 features
        ]

        # Optionally add interference (excluded by default due to low importance)
        if include_interference:
            interference = self.compute_interference_features(qv_vector)
            features_to_concat.append(interference)  # 39 features

        # Always include density
        features_to_concat.append(density.flatten())  # 39 × len(windows) features

        # Concatenate all features
        all_features = np.concatenate(features_to_concat)

        # Generate feature names
        feature_names = []

        # Min distance features
        for i in range(1, 40):
            feature_names.append(f'QV_{i}_min_dist_to_winner')

        # Tunneling features
        for i in range(1, 40):
            feature_names.append(f'QV_{i}_tunnel_influence')

        # Interference features (optional)
        if include_interference:
            for i in range(1, 40):
                feature_names.append(f'QV_{i}_interference_intensity')

        # Local density features
        for window in windows:
            for i in range(1, 40):
                feature_names.append(f'QV_{i}_local_density_r{window}')

        return all_features, feature_names
