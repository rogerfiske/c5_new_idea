"""
Unified Training Script for Ranking Models

This script provides a unified interface for training all ranking model types
on imputed quantum state data. It supports:
- All ranker families (Frequency, LGBM, SetTransformer, GNN)
- Cross-validation for robust evaluation
- Hyperparameter configuration
- Model persistence
- Performance tracking (NFR1 requirement)

Usage:
    # Train a single ranker
    python -m src.modeling.train_rankers --ranker lgbm --imputation onehot --output models/

    # Train all rankers with cross-validation
    python -m src.modeling.train_rankers --ranker all --imputation onehot --cv 5 --output models/

    # Train with custom hyperparameters
    python -m src.modeling.train_rankers --ranker set_transformer --imputation basis \
        --config configs/set_transformer.json --output models/

Author: BMad Dev Agent (James)
Date: 2025-10-14
Story: Epic 3, Story 3.6 - Unified Training Script
"""

import argparse
import json
import logging
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any
import numpy as np
import pandas as pd
from datetime import datetime

from src.modeling.rankers import (
    BaseRanker,
    FrequencyRanker,
    LGBMRanker,
    SetTransformerRanker,
    GNNRanker
)

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


# Available ranker types
RANKER_TYPES = {
    'frequency': FrequencyRanker,
    'lgbm': LGBMRanker,
    'set_transformer': SetTransformerRanker,
    'gnn': GNNRanker,
}


# Default hyperparameters for each ranker type
DEFAULT_HYPERPARAMETERS = {
    'frequency': {
        'method': 'cumulative'  # Options: cumulative, ema, bigram
    },
    'lgbm': {
        'num_iterations': 100,
        'learning_rate': 0.05,
        'max_depth': 6,
        'num_leaves': 31,
    },
    'set_transformer': {
        'd_model': 128,
        'num_heads': 4,
        'num_encoder_layers': 2,
        'epochs': 50,
        'batch_size': 32,
    },
    'gnn': {
        'd_model': 128,
        'num_heads': 4,
        'num_gat_layers': 3,
        'epochs': 50,
        'batch_size': 32,
    }
}


def load_imputed_data(imputation_strategy: str, data_dir: Path) -> pd.DataFrame:
    """
    Load imputed data for training.

    Args:
        imputation_strategy: Name of imputation strategy (onehot, basis, etc.)
        data_dir: Directory containing imputed data files

    Returns:
        DataFrame with imputed features

    Raises:
        FileNotFoundError: If imputed data file doesn't exist
        ValueError: If data is empty or malformed
    """
    # Look for imputed data file
    imputed_file = data_dir / f"imputed_{imputation_strategy}.csv"

    if not imputed_file.exists():
        raise FileNotFoundError(
            f"Imputed data file not found: {imputed_file}\n"
            f"Please run imputation first:\n"
            f"  python -m src.imputation.apply_imputation --strategy {imputation_strategy} --output {data_dir}"
        )

    logger.info(f"Loading imputed data from {imputed_file}")
    df = pd.read_csv(imputed_file)

    if df.empty:
        raise ValueError(f"Imputed data file is empty: {imputed_file}")

    logger.info(f"✓ Loaded {len(df)} samples with {len(df.columns)} features")

    return df


def create_train_test_split(
    df: pd.DataFrame,
    test_size: float = 0.2,
    random_state: int = 42
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    Create train/test split from imputed data.

    Args:
        df: Imputed feature data
        test_size: Fraction of data for test set
        random_state: Random seed for reproducibility

    Returns:
        (train_df, test_df) tuple
    """
    np.random.seed(random_state)

    n_samples = len(df)
    n_test = int(n_samples * test_size)
    n_train = n_samples - n_test

    # Shuffle indices
    indices = np.random.permutation(n_samples)
    train_indices = indices[:n_train]
    test_indices = indices[n_train:]

    train_df = df.iloc[train_indices].reset_index(drop=True)
    test_df = df.iloc[test_indices].reset_index(drop=True)

    logger.info(f"Train/test split: {n_train}/{n_test} samples")

    return train_df, test_df


def create_cv_splits(
    df: pd.DataFrame,
    n_splits: int = 5,
    random_state: int = 42
) -> List[Tuple[pd.DataFrame, pd.DataFrame]]:
    """
    Create k-fold cross-validation splits.

    Args:
        df: Full dataset
        n_splits: Number of CV folds
        random_state: Random seed

    Returns:
        List of (train_df, val_df) tuples for each fold
    """
    np.random.seed(random_state)

    n_samples = len(df)
    indices = np.random.permutation(n_samples)

    fold_size = n_samples // n_splits
    splits = []

    for fold in range(n_splits):
        # Validation indices for this fold
        val_start = fold * fold_size
        val_end = val_start + fold_size if fold < n_splits - 1 else n_samples
        val_indices = indices[val_start:val_end]

        # Training indices (everything except validation)
        train_indices = np.concatenate([indices[:val_start], indices[val_end:]])

        train_df = df.iloc[train_indices].reset_index(drop=True)
        val_df = df.iloc[val_indices].reset_index(drop=True)

        splits.append((train_df, val_df))

    logger.info(f"Created {n_splits}-fold CV splits")

    return splits


def load_hyperparameters(config_file: Optional[Path]) -> Dict[str, Any]:
    """
    Load hyperparameters from JSON config file.

    Args:
        config_file: Path to JSON config file (optional)

    Returns:
        Dictionary of hyperparameters
    """
    if config_file is None:
        return {}

    if not config_file.exists():
        raise FileNotFoundError(f"Config file not found: {config_file}")

    logger.info(f"Loading hyperparameters from {config_file}")

    with open(config_file, 'r') as f:
        params = json.load(f)

    logger.info(f"✓ Loaded hyperparameters: {params}")

    return params


def train_ranker(
    ranker_type: str,
    train_df: pd.DataFrame,
    hyperparameters: Optional[Dict[str, Any]] = None,
    track_time: bool = True
) -> BaseRanker:
    """
    Train a single ranker model.

    Args:
        ranker_type: Type of ranker (frequency, lgbm, set_transformer, gnn)
        train_df: Training data
        hyperparameters: Custom hyperparameters (optional)
        track_time: Whether to track training time (NFR1)

    Returns:
        Trained ranker instance

    Raises:
        ValueError: If ranker_type is unknown
    """
    if ranker_type not in RANKER_TYPES:
        raise ValueError(
            f"Unknown ranker type: {ranker_type}\n"
            f"Available types: {list(RANKER_TYPES.keys())}"
        )

    # Get ranker class
    ranker_class = RANKER_TYPES[ranker_type]

    # Merge with default hyperparameters
    params = DEFAULT_HYPERPARAMETERS.get(ranker_type, {}).copy()
    if hyperparameters is not None:
        params.update(hyperparameters)

    logger.info(f"Training {ranker_type} ranker with {len(train_df)} samples...")
    logger.info(f"Hyperparameters: {params}")

    # Create and train ranker
    start_time = time.time()

    # FrequencyRanker has different initialization signature
    if ranker_type == 'frequency':
        ranker = ranker_class(
            method=params.get('method', 'cumulative'),
            alpha=params.get('alpha', 0.1),
            normalize=params.get('normalize', True)
        )
    else:
        ranker = ranker_class(params=params, track_time=track_time)

    ranker.fit(train_df)
    training_time = time.time() - start_time

    logger.info(f"✓ {ranker_type} training completed in {training_time:.2f}s")

    return ranker


def evaluate_ranker(
    ranker: BaseRanker,
    test_df: pd.DataFrame,
    k_values: List[int] = [5, 10, 20]
) -> Dict[str, float]:
    """
    Evaluate ranker performance on test data.

    Computes top-k accuracy for different k values.

    Args:
        ranker: Trained ranker
        test_df: Test data
        k_values: List of k values for top-k accuracy

    Returns:
        Dictionary of evaluation metrics
    """
    logger.info(f"Evaluating {ranker.get_name()} on {len(test_df)} test samples...")

    metrics = {}

    for k in k_values:
        # Predict top-k positions
        predictions = ranker.predict_top_k(test_df, k=k)

        # Extract true active positions from test data
        true_positions = []
        for idx, row in test_df.iterrows():
            active_cols = row[row > 0].index.tolist()
            active_positions = []

            for col in active_cols:
                col_str = str(col)
                if 'qv_' in col_str and '_onehot' in col_str:
                    parts = col_str.split('_')
                    if len(parts) >= 2 and parts[1].isdigit():
                        pos = int(parts[1])
                        if 1 <= pos <= 39:
                            active_positions.append(pos)

            true_positions.append(set(active_positions))

        # Compute top-k accuracy (at least 1 correct position in top-k)
        correct = 0
        for i, pred_row in enumerate(predictions):
            if len(true_positions[i]) > 0:
                pred_set = set(pred_row)
                if len(pred_set.intersection(true_positions[i])) > 0:
                    correct += 1

        accuracy = correct / len(test_df) if len(test_df) > 0 else 0.0
        metrics[f'top{k}_accuracy'] = accuracy

        logger.info(f"  Top-{k} Accuracy: {accuracy:.4f}")

    return metrics


def save_model_and_results(
    ranker: BaseRanker,
    ranker_type: str,
    imputation_strategy: str,
    metrics: Dict[str, float],
    output_dir: Path,
    fold: Optional[int] = None
):
    """
    Save trained model and evaluation results.

    Args:
        ranker: Trained ranker
        ranker_type: Type of ranker
        imputation_strategy: Imputation strategy used
        metrics: Evaluation metrics
        output_dir: Directory to save outputs
        fold: CV fold number (optional)
    """
    output_dir.mkdir(parents=True, exist_ok=True)

    # Create filename
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    fold_str = f"_fold{fold}" if fold is not None else ""
    base_name = f"{ranker_type}_{imputation_strategy}{fold_str}_{timestamp}"

    # Save model (if ranker supports it)
    # FrequencyRanker doesn't need model persistence (just frequencies)
    if hasattr(ranker, 'save_model') and callable(getattr(ranker, 'save_model')):
        model_path = output_dir / f"{base_name}.pth"
        ranker.save_model(model_path, save_metadata=True)
        logger.info(f"✓ Model saved to {model_path}")
    else:
        logger.info(f"✓ Ranker {ranker_type} doesn't require model persistence")

    # Save results
    results = {
        'ranker_type': ranker_type,
        'imputation_strategy': imputation_strategy,
        'fold': fold,
        'timestamp': timestamp,
        'training_time': ranker.training_time_ if hasattr(ranker, 'training_time_') else None,
        'metrics': metrics
    }

    results_path = output_dir / f"{base_name}_results.json"
    with open(results_path, 'w') as f:
        json.dump(results, f, indent=2)

    logger.info(f"✓ Results saved to {results_path}")


def train_single_ranker(
    ranker_type: str,
    imputation_strategy: str,
    data_dir: Path,
    output_dir: Path,
    config_file: Optional[Path] = None,
    cv_folds: Optional[int] = None,
    test_size: float = 0.2,
):
    """
    Train a single ranker type with optional cross-validation.

    Args:
        ranker_type: Type of ranker to train
        imputation_strategy: Imputation strategy to use
        data_dir: Directory containing imputed data
        output_dir: Directory to save models and results
        config_file: Path to hyperparameter config (optional)
        cv_folds: Number of CV folds (None = simple train/test split)
        test_size: Test set size if not using CV
    """
    logger.info(f"=" * 80)
    logger.info(f"Training {ranker_type} ranker with {imputation_strategy} imputation")
    logger.info(f"=" * 80)

    # Load data
    df = load_imputed_data(imputation_strategy, data_dir)

    # Load hyperparameters
    hyperparameters = load_hyperparameters(config_file)

    if cv_folds is not None:
        # Cross-validation mode
        logger.info(f"Using {cv_folds}-fold cross-validation")

        splits = create_cv_splits(df, n_splits=cv_folds)
        all_metrics = []

        for fold, (train_df, val_df) in enumerate(splits):
            logger.info(f"\n--- Fold {fold + 1}/{cv_folds} ---")

            # Train ranker
            ranker = train_ranker(ranker_type, train_df, hyperparameters)

            # Evaluate
            metrics = evaluate_ranker(ranker, val_df)
            all_metrics.append(metrics)

            # Save
            save_model_and_results(
                ranker, ranker_type, imputation_strategy, metrics, output_dir, fold=fold
            )

        # Report average metrics
        logger.info(f"\n--- Cross-Validation Results ---")
        avg_metrics = {}
        for key in all_metrics[0].keys():
            values = [m[key] for m in all_metrics]
            avg_metrics[key] = np.mean(values)
            std_metrics = np.std(values)
            logger.info(f"{key}: {avg_metrics[key]:.4f} ± {std_metrics:.4f}")

    else:
        # Simple train/test split
        logger.info(f"Using simple train/test split ({100*(1-test_size):.0f}%/{100*test_size:.0f}%)")

        train_df, test_df = create_train_test_split(df, test_size=test_size)

        # Train ranker
        ranker = train_ranker(ranker_type, train_df, hyperparameters)

        # Evaluate
        metrics = evaluate_ranker(ranker, test_df)

        # Save
        save_model_and_results(
            ranker, ranker_type, imputation_strategy, metrics, output_dir
        )

    logger.info(f"\n✓ Training complete for {ranker_type} ranker")


def train_all_rankers(
    imputation_strategy: str,
    data_dir: Path,
    output_dir: Path,
    cv_folds: Optional[int] = None,
    test_size: float = 0.2,
):
    """
    Train all available ranker types.

    Args:
        imputation_strategy: Imputation strategy to use
        data_dir: Directory containing imputed data
        output_dir: Directory to save models and results
        cv_folds: Number of CV folds (optional)
        test_size: Test set size if not using CV
    """
    logger.info("=" * 80)
    logger.info("Training ALL ranker types")
    logger.info("=" * 80)

    for ranker_type in RANKER_TYPES.keys():
        try:
            train_single_ranker(
                ranker_type=ranker_type,
                imputation_strategy=imputation_strategy,
                data_dir=data_dir,
                output_dir=output_dir,
                cv_folds=cv_folds,
                test_size=test_size
            )
        except Exception as e:
            logger.error(f"Failed to train {ranker_type}: {e}")
            logger.error("Continuing with next ranker...")

    logger.info("\n" + "=" * 80)
    logger.info("✓ All ranker training complete")
    logger.info("=" * 80)


def main():
    """Main entry point for training script."""
    parser = argparse.ArgumentParser(
        description="Train ranking models on imputed quantum state data",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Train LGBM ranker with onehot imputation
  python -m src.modeling.train_rankers --ranker lgbm --imputation onehot --output models/

  # Train all rankers with 5-fold cross-validation
  python -m src.modeling.train_rankers --ranker all --imputation basis --cv 5 --output models/

  # Train with custom hyperparameters
  python -m src.modeling.train_rankers --ranker set_transformer --imputation onehot \\
      --config configs/set_transformer.json --output models/
        """
    )

    parser.add_argument(
        '--ranker',
        type=str,
        required=True,
        choices=list(RANKER_TYPES.keys()) + ['all'],
        help='Type of ranker to train (or "all" for all types)'
    )

    parser.add_argument(
        '--imputation',
        type=str,
        required=True,
        help='Imputation strategy to use (e.g., onehot, basis, angle, etc.)'
    )

    parser.add_argument(
        '--data-dir',
        type=Path,
        default=Path('data/imputed'),
        help='Directory containing imputed data files (default: data/imputed/)'
    )

    parser.add_argument(
        '--output',
        type=Path,
        required=True,
        help='Output directory for trained models and results'
    )

    parser.add_argument(
        '--config',
        type=Path,
        default=None,
        help='Path to JSON config file with hyperparameters (optional)'
    )

    parser.add_argument(
        '--cv',
        type=int,
        default=None,
        help='Number of cross-validation folds (default: simple train/test split)'
    )

    parser.add_argument(
        '--test-size',
        type=float,
        default=0.2,
        help='Test set size fraction if not using CV (default: 0.2)'
    )

    args = parser.parse_args()

    # Validate arguments
    if args.cv is not None and args.cv < 2:
        parser.error("--cv must be at least 2")

    if not (0 < args.test_size < 1):
        parser.error("--test-size must be between 0 and 1")

    # Train rankers
    try:
        if args.ranker == 'all':
            train_all_rankers(
                imputation_strategy=args.imputation,
                data_dir=args.data_dir,
                output_dir=args.output,
                cv_folds=args.cv,
                test_size=args.test_size
            )
        else:
            train_single_ranker(
                ranker_type=args.ranker,
                imputation_strategy=args.imputation,
                data_dir=args.data_dir,
                output_dir=args.output,
                config_file=args.config,
                cv_folds=args.cv,
                test_size=args.test_size
            )

        logger.info("\n🎉 Training workflow completed successfully!")
        return 0

    except Exception as e:
        logger.error(f"\n❌ Training failed: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == '__main__':
    sys.exit(main())
