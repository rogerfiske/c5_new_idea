"""
Frequency-Based Baseline Rankers

This module implements frequency-based baseline ranking approaches that
establish performance benchmarks for more complex ML models. These rankers
use simple statistical methods to rank quantum positions based on historical
patterns observed in the training data.

Implemented Methods:
    1. Cumulative Frequency: Rank by overall position frequency
    2. EMA (Exponential Moving Average): Weight recent events more heavily
    3. Bigram/Co-occurrence: Rank based on position pair patterns

Author: BMad Dev Agent (James)
Date: 2025-10-13
Story: Epic 3, Story 3.2 - Frequency-Based Baseline Rankers
"""

from typing import Dict, List, Optional
import numpy as np
import pandas as pd
from collections import defaultdict, Counter

from .base_ranker import BaseRanker


class FrequencyRanker(BaseRanker):
    """
    Baseline ranker using frequency-based methods.

    This ranker uses simple statistical approaches to rank quantum positions
    based on their historical frequencies in the training data. Three methods
    are supported:

    1. **Cumulative Frequency** ('cumulative'):
       - Counts how many times each position appears in training data
       - Ranks positions by overall frequency (most frequent → highest rank)
       - Assumes past frequencies are good predictors of future states
       - Simplest baseline, no temporal weighting

    2. **Exponential Moving Average** ('ema'):
       - Weights recent events more heavily than older events
       - Uses exponential decay: weight_t = α^(T-t) where T is latest event
       - Captures temporal trends and shifting patterns
       - Configurable α parameter (default: 0.1)

    3. **Bigram/Co-occurrence** ('bigram'):
       - Learns which position pairs frequently co-occur in same event
       - For test sample, finds positions present and ranks by co-occurrence
       - Captures structural relationships between positions
       - Uses co-occurrence matrix: M[i, j] = count of events with both i and j

    Args:
        method: Ranking method to use
            Options: 'cumulative', 'ema', 'bigram'
            Default: 'cumulative'
        alpha: EMA decay parameter (only used for method='ema')
            Must be in range (0, 1)
            Smaller α → more weight on recent events
            Default: 0.1 (strong recency bias)
        normalize: Whether to normalize frequencies to probabilities
            Default: True (converts counts to probabilities summing to 1.0)

    Attributes:
        position_frequencies: Dict[int, float]
            Learned frequencies for each position (1-39)
            Set during fit(), used during predict_top_k()
        cooccurrence_matrix: np.ndarray or None
            39x39 matrix of position co-occurrence counts (for bigram method)
            cooccurrence_matrix[i, j] = count of events with both positions i+1 and j+1
            Only populated for method='bigram'

    Example:
        >>> # Cumulative frequency baseline
        >>> ranker = FrequencyRanker(method='cumulative')
        >>> ranker.fit(X_train, y_train)
        >>> predictions = ranker.predict_top_k(X_test, k=20)

        >>> # EMA baseline with strong recency bias
        >>> ranker = FrequencyRanker(method='ema', alpha=0.05)
        >>> ranker.fit(X_train, y_train)
        >>> predictions = ranker.predict_top_k(X_test, k=20)

        >>> # Bigram co-occurrence baseline
        >>> ranker = FrequencyRanker(method='bigram')
        >>> ranker.fit(X_train, y_train)
        >>> predictions = ranker.predict_top_k(X_test, k=20)

    Notes:
        - These are UNSUPERVISED methods: y_train is not used (can be None)
        - Training data X_train should contain binary features indicating active positions
        - For EMA: assumes X_train is in chronological order (temporal ordering)
        - For bigram: requires at least 2 active positions per event to learn co-occurrences
    """

    VALID_METHODS = {'cumulative', 'ema', 'bigram'}

    def __init__(self, method: str = 'cumulative', alpha: float = 0.1, normalize: bool = True):
        """
        Initialize frequency-based ranker.

        Args:
            method: 'cumulative', 'ema', or 'bigram'
            alpha: EMA decay parameter (0, 1), only for method='ema'
            normalize: Whether to normalize frequencies to probabilities

        Raises:
            ValueError: If method not in VALID_METHODS
            ValueError: If alpha not in range (0, 1) when method='ema'
        """
        super().__init__()

        # Validate method
        if method not in self.VALID_METHODS:
            raise ValueError(
                f"method must be one of {self.VALID_METHODS}, got '{method}'. "
                "Choose 'cumulative' for overall frequency, 'ema' for temporal weighting, "
                "or 'bigram' for co-occurrence patterns."
            )

        # Validate alpha for EMA
        if method == 'ema' and not (0 < alpha < 1):
            raise ValueError(
                f"alpha must be in range (0, 1) for EMA method, got {alpha}. "
                "Smaller α (e.g., 0.05) gives more weight to recent events. "
                "Larger α (e.g., 0.5) smooths over longer history."
            )

        self.method = method
        self.alpha = alpha
        self.normalize = normalize

        # Learned parameters (set during fit)
        self.position_frequencies: Optional[Dict[int, float]] = None
        self.cooccurrence_matrix: Optional[np.ndarray] = None

    def fit(self, X_train: pd.DataFrame, y_train: Optional[pd.Series] = None):
        """
        Learn frequency statistics from training data.

        This method extracts position frequencies using the selected method:
        - cumulative: Count total occurrences of each position
        - ema: Count occurrences with exponential time weighting
        - bigram: Build co-occurrence matrix of position pairs

        Args:
            X_train: Training features with binary position indicators
                Expected: Imputed data from Epic 2 (e.g., basis embedding one-hot)
                OR raw binary matrix with columns for each of 39 positions
            y_train: Not used (unsupervised method), can be None

        Returns:
            self: Returns self for method chaining

        Raises:
            ValueError: If X_train is empty or has wrong shape
            RuntimeError: If no active positions found in training data
        """
        # Validate input
        if X_train.empty:
            raise ValueError("X_train cannot be empty")

        if len(X_train) < 10:
            raise ValueError(
                f"X_train too small: {len(X_train)} samples. "
                "Need at least 10 samples for meaningful frequency statistics."
            )

        # Extract active positions from each training sample
        # Active positions are those with value > 0 in the binary representation
        active_positions_list = self._extract_active_positions(X_train)

        if len(active_positions_list) == 0:
            raise RuntimeError(
                "No active positions found in training data. "
                "Check that X_train contains binary features indicating active positions."
            )

        # Learn statistics using selected method
        if self.method == 'cumulative':
            self._fit_cumulative(active_positions_list)
        elif self.method == 'ema':
            self._fit_ema(active_positions_list)
        elif self.method == 'bigram':
            self._fit_bigram(active_positions_list)

        self.is_fitted_ = True
        return self

    def predict_top_k(self, X_test: pd.DataFrame, k: int = 20) -> np.ndarray:
        """
        Predict top-k ranked positions for each test sample.

        For cumulative and EMA methods:
            - Returns same ranking for all test samples (global frequencies)
            - Ranking is independent of test sample content

        For bigram method:
            - Returns sample-specific ranking based on co-occurrences with
              positions present in the test sample
            - Different test samples may get different rankings

        Args:
            X_test: Test features (same format as X_train)
                Shape: (n_samples, n_features)
            k: Number of top predictions to return
                Default: 20 (as per project requirements)
                Must be in range [1, 39]

        Returns:
            predictions: Top-k ranked position predictions
                Shape: (n_samples, k)
                Each row contains k position indices (1-39) ranked by likelihood
                Position with highest likelihood at index 0, second at index 1, etc.

        Raises:
            RuntimeError: If called before fit()
            ValueError: If k not in range [1, 39]
            ValueError: If X_test has wrong format

        Example:
            >>> predictions = ranker.predict_top_k(X_test, k=20)
            >>> predictions.shape
            (1000, 20)  # 1000 test samples, 20 predictions each
            >>> predictions[0]  # First test sample's predictions
            array([ 5, 12, 33, 7, 20, 1, ...])  # Top 20 positions
        """
        # Validation
        self._check_is_fitted()
        self._validate_k(k)

        if X_test.empty:
            raise ValueError("X_test cannot be empty")

        n_samples = len(X_test)

        # For cumulative and EMA: return same ranking for all samples
        if self.method in ['cumulative', 'ema']:
            # Sort positions by frequency (descending)
            sorted_positions = sorted(
                self.position_frequencies.items(),
                key=lambda x: x[1],
                reverse=True
            )
            # Extract top-k position indices
            top_k_positions = np.array([pos for pos, freq in sorted_positions[:k]])

            # Repeat for all test samples (same ranking)
            predictions = np.tile(top_k_positions, (n_samples, 1))

        # For bigram: compute sample-specific rankings
        elif self.method == 'bigram':
            predictions = self._predict_bigram(X_test, k)

        return predictions

    def _extract_active_positions(self, X: pd.DataFrame) -> List[List[int]]:
        """
        Extract active position indices from feature matrix.

        PATH A FIX: Explicitly use QV_1...QV_39 binary columns to identify
        which positions are currently active. These columns contain 0/1 values
        indicating the binary state of the quantum system.

        Args:
            X: Feature DataFrame with QV_1 through QV_39 columns
                Expected format from Epic 4: binary state + imputed features + targets

        Returns:
            active_positions_list: List of active position lists
                Each inner list contains position indices (1-39) active in that sample
                Example: [[1, 5, 12, 33, 38], [2, 7, 10, 20, 35], ...]

        Raises:
            ValueError: If QV columns are missing from data

        Notes:
            - Position indices are 1-based (1 to 39), not 0-based
            - PATH A: Uses QV columns explicitly (not auto-detection)
        """
        # PATH A FIX: Explicitly use QV columns (binary state)
        qv_columns = [f'QV_{i}' for i in range(1, 40)]

        # Verify QV columns exist
        missing_cols = [col for col in qv_columns if col not in X.columns]
        if missing_cols:
            raise ValueError(
                f"Missing QV columns in data. Expected QV_1 through QV_39. "
                f"Missing: {missing_cols[:5]}... ({len(missing_cols)} total). "
                f"Available columns: {list(X.columns[:10])}..."
            )

        X_binary = X[qv_columns]
        active_positions_list = []

        # Extract active positions (where QV_i == 1)
        for idx, row in X_binary.iterrows():
            active_positions = []
            for i, col in enumerate(qv_columns, start=1):
                if row[col] == 1:
                    active_positions.append(i)

            active_positions_list.append(active_positions)

        return active_positions_list

    def _fit_cumulative(self, active_positions_list: List[List[int]]):
        """
        Fit cumulative frequency model.

        Counts total occurrences of each position across all training samples.

        Args:
            active_positions_list: List of active positions per sample
        """
        # Count occurrences of each position
        position_counts = Counter()
        for positions in active_positions_list:
            position_counts.update(positions)

        # Convert to frequencies (normalize if requested)
        if self.normalize:
            total_count = sum(position_counts.values())
            self.position_frequencies = {
                pos: count / total_count
                for pos, count in position_counts.items()
            }
        else:
            self.position_frequencies = dict(position_counts)

        # Ensure all positions 1-39 have an entry (default to 0)
        for pos in range(1, 40):
            if pos not in self.position_frequencies:
                self.position_frequencies[pos] = 0.0

    def _fit_ema(self, active_positions_list: List[List[int]]):
        """
        Fit exponential moving average model.

        Weights recent events more heavily using exponential decay.
        Weight for event t: α^(T-t) where T is the total number of events.

        Args:
            active_positions_list: List of active positions per sample (chronological order)
        """
        # Initialize weighted position counts
        position_weights = defaultdict(float)

        T = len(active_positions_list)  # Total number of events

        # Apply exponential weighting: recent events get higher weight
        for t, positions in enumerate(active_positions_list):
            # Weight decreases exponentially as we go back in time
            # Most recent event (t = T-1): weight = α^0 = 1.0
            # Oldest event (t = 0): weight = α^(T-1)
            weight = self.alpha ** (T - 1 - t)

            for pos in positions:
                position_weights[pos] += weight

        # Normalize if requested
        if self.normalize:
            total_weight = sum(position_weights.values())
            self.position_frequencies = {
                pos: weight / total_weight
                for pos, weight in position_weights.items()
            }
        else:
            self.position_frequencies = dict(position_weights)

        # Ensure all positions 1-39 have an entry
        for pos in range(1, 40):
            if pos not in self.position_frequencies:
                self.position_frequencies[pos] = 0.0

    def _fit_bigram(self, active_positions_list: List[List[int]]):
        """
        Fit bigram co-occurrence model.

        Builds a 39x39 matrix counting how often each pair of positions
        co-occurs in the same event.

        Args:
            active_positions_list: List of active positions per sample
        """
        # Initialize co-occurrence matrix (39x39)
        # Entry [i, j] = count of events where both position i+1 and j+1 are active
        self.cooccurrence_matrix = np.zeros((39, 39), dtype=np.float64)

        # Count co-occurrences
        for positions in active_positions_list:
            # For each pair of positions in this event
            for i, pos_i in enumerate(positions):
                for pos_j in positions[i+1:]:  # Only count each pair once
                    # Increment both (i, j) and (j, i) for symmetry
                    self.cooccurrence_matrix[pos_i - 1, pos_j - 1] += 1
                    self.cooccurrence_matrix[pos_j - 1, pos_i - 1] += 1

        # Normalize if requested (each row sums to 1)
        if self.normalize:
            row_sums = self.cooccurrence_matrix.sum(axis=1, keepdims=True)
            # Avoid division by zero
            row_sums[row_sums == 0] = 1.0
            self.cooccurrence_matrix = self.cooccurrence_matrix / row_sums

        # For predict, we'll also store marginal frequencies as fallback
        # when test sample has no active positions or low co-occurrence
        position_counts = Counter()
        for positions in active_positions_list:
            position_counts.update(positions)

        if self.normalize:
            total_count = sum(position_counts.values())
            self.position_frequencies = {
                pos: count / total_count
                for pos, count in position_counts.items()
            }
        else:
            self.position_frequencies = dict(position_counts)

        for pos in range(1, 40):
            if pos not in self.position_frequencies:
                self.position_frequencies[pos] = 0.0

    def _predict_bigram(self, X_test: pd.DataFrame, k: int) -> np.ndarray:
        """
        Predict using bigram co-occurrence model.

        For each test sample:
        1. Extract active positions
        2. Sum co-occurrence scores for each candidate position
        3. Rank candidates by total co-occurrence score
        4. Return top-k positions

        Args:
            X_test: Test features
            k: Number of top predictions

        Returns:
            predictions: Top-k ranked positions per sample
                Shape: (n_samples, k)
        """
        active_positions_test = self._extract_active_positions(X_test)
        n_samples = len(X_test)
        predictions = np.zeros((n_samples, k), dtype=np.int32)

        for sample_idx in range(n_samples):
            # Get active positions for this test sample
            if sample_idx < len(active_positions_test):
                active_positions = active_positions_test[sample_idx]
            else:
                active_positions = []

            # Compute co-occurrence scores for all positions
            scores = np.zeros(39)

            if len(active_positions) > 0:
                # Sum co-occurrence counts with active positions
                for pos in active_positions:
                    scores += self.cooccurrence_matrix[pos - 1, :]
            else:
                # Fallback: use marginal frequencies if no active positions
                for pos in range(1, 40):
                    scores[pos - 1] = self.position_frequencies[pos]

            # Rank positions by score (descending)
            ranked_positions = np.argsort(-scores) + 1  # +1 for 1-based indexing

            # Take top-k
            predictions[sample_idx] = ranked_positions[:k]

        return predictions

    def __repr__(self) -> str:
        """String representation with method and parameters."""
        fitted_status = "fitted" if self.is_fitted_ else "not fitted"
        if self.method == 'ema':
            return f"FrequencyRanker(method='{self.method}', alpha={self.alpha}, {fitted_status})"
        else:
            return f"FrequencyRanker(method='{self.method}', {fitted_status})"
