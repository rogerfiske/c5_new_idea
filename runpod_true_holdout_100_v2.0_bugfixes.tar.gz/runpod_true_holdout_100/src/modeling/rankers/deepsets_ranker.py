"""
Set Transformer Ranker for Advanced Set-Based Ranking

This module implements a Set Transformer architecture for ranking quantum positions.
Set Transformers use attention mechanisms to process sets, providing superior
performance compared to DeepSets by learning complex interactions between elements.

Key Concept:
    Set Transformers use multi-head self-attention to capture rich relationships
    between the 5 active positions, then pool this information to predict
    ranking scores for all 39 possible positions.

Architecture Components:
    1. Multi-Head Attention (MAB): Core attention mechanism
    2. Induced Set Attention Block (ISAB): Efficient attention with inducing points
    3. Pooling by Multihead Attention (PMA): Fixed-size pooling
    4. Feed-Forward Networks: Non-linear transformations
    5. Layer Normalization: Training stability

Mathematical Foundation:
    Attention(Q, K, V) = softmax(QK^T / √d_k)V
    MultiHead(Q, K, V) = Concat(head₁, ..., head_h)W^O
    where head_i = Attention(QW_i^Q, KW_i^K, VW_i^V)

Performance Advantages over DeepSets:
    - Learns pairwise and higher-order interactions between positions
    - Attention weights provide interpretability
    - More expressive capacity for complex patterns
    - Scales well with GPU acceleration (batched attention)

Author: BMad Dev Agent (James)
Date: 2025-10-14
Story: Epic 3, Story 3.4 - Set-Based Ranker (Set Transformer Architecture)
"""

import time
import json
import logging
import math
from pathlib import Path
from typing import Dict, Optional, Any, Tuple
import numpy as np
import pandas as pd

try:
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
    import torch.optim as optim
    from torch.utils.data import DataLoader, TensorDataset
    TORCH_AVAILABLE = True
except ImportError:
    TORCH_AVAILABLE = False

from .base_ranker import BaseRanker

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


# Default hyperparameters
DEFAULT_SET_TRANSFORMER_PARAMS = {
    'd_model': 128,  # Model dimension
    'num_heads': 4,  # Number of attention heads
    'num_inds': 16,  # Number of inducing points in ISAB
    'num_encoder_layers': 2,  # Number of ISAB layers
    'dim_feedforward': 256,  # Feed-forward dimension
    'num_seeds': 1,  # Number of seed vectors for PMA pooling
    'learning_rate': 0.0001,
    'batch_size': 32,
    'epochs': 100,
    'early_stopping_patience': 10,
    'dropout': 0.1,
    'weight_decay': 1e-5,
    'device': 'cpu',
}


class MultiHeadAttentionBlock(nn.Module):
    """
    Multi-Head Attention Block (MAB).

    Implements multi-head attention with residual connection and layer norm.
    This is the fundamental building block of Set Transformers.

    Args:
        d_model: Model dimension
        num_heads: Number of attention heads
        dropout: Dropout probability

    Mathematical Operation:
        MAB(X, Y) = LayerNorm(H + rFF(H))
        where H = LayerNorm(X + Multihead(X, Y, Y))
    """

    def __init__(self, d_model: int, num_heads: int, dropout: float = 0.1):
        super().__init__()

        assert d_model % num_heads == 0, "d_model must be divisible by num_heads"

        self.d_model = d_model
        self.num_heads = num_heads
        self.d_k = d_model // num_heads

        # Multi-head attention
        self.multihead_attn = nn.MultiheadAttention(
            embed_dim=d_model,
            num_heads=num_heads,
            dropout=dropout,
            batch_first=True
        )

        # Feed-forward network
        self.ff = nn.Sequential(
            nn.Linear(d_model, d_model * 4),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(d_model * 4, d_model),
            nn.Dropout(dropout)
        )

        # Layer normalization
        self.ln1 = nn.LayerNorm(d_model)
        self.ln2 = nn.LayerNorm(d_model)

    def forward(self, X, Y):
        """
        Forward pass through MAB.

        Args:
            X: Query input (batch, n_query, d_model)
            Y: Key/Value input (batch, n_kv, d_model)

        Returns:
            Output (batch, n_query, d_model)
        """
        # Multi-head attention with residual
        H, _ = self.multihead_attn(X, Y, Y)
        H = self.ln1(X + H)

        # Feed-forward with residual
        out = self.ln2(H + self.ff(H))

        return out


class InducedSetAttentionBlock(nn.Module):
    """
    Induced Set Attention Block (ISAB).

    Uses inducing points to reduce computational complexity from O(n²) to O(nm),
    where n is set size and m is number of inducing points.

    Args:
        d_model: Model dimension
        num_heads: Number of attention heads
        num_inds: Number of inducing points
        dropout: Dropout probability

    Mathematical Operation:
        ISAB(X) = MAB(X, MAB(I, X))
        where I are learnable inducing points

    This decomposition allows the model to process large sets efficiently
    while maintaining expressive power through the inducing points bottleneck.
    """

    def __init__(self, d_model: int, num_heads: int, num_inds: int, dropout: float = 0.1):
        super().__init__()

        # Learnable inducing points
        self.inducing_points = nn.Parameter(torch.randn(1, num_inds, d_model))

        # Two MAB layers
        self.mab1 = MultiHeadAttentionBlock(d_model, num_heads, dropout)
        self.mab2 = MultiHeadAttentionBlock(d_model, num_heads, dropout)

    def forward(self, X):
        """
        Forward pass through ISAB.

        Args:
            X: Input set (batch, n_elements, d_model)

        Returns:
            Output set (batch, n_elements, d_model)
        """
        batch_size = X.shape[0]

        # Expand inducing points for batch
        I = self.inducing_points.expand(batch_size, -1, -1)

        # Two-stage attention
        H = self.mab1(I, X)  # (batch, num_inds, d_model)
        out = self.mab2(X, H)  # (batch, n_elements, d_model)

        return out


class PoolingByMultiheadAttention(nn.Module):
    """
    Pooling by Multihead Attention (PMA).

    Reduces a variable-size set to a fixed-size representation using
    attention-based pooling with learnable seed vectors.

    Args:
        d_model: Model dimension
        num_heads: Number of attention heads
        num_seeds: Number of seed vectors (output size)
        dropout: Dropout probability

    Mathematical Operation:
        PMA(X) = MAB(S, X)
        where S are learnable seed vectors

    The seed vectors act as queries that attend to the entire input set,
    producing a fixed-size summary representation.
    """

    def __init__(self, d_model: int, num_heads: int, num_seeds: int, dropout: float = 0.1):
        super().__init__()

        # Learnable seed vectors
        self.seed_vectors = nn.Parameter(torch.randn(1, num_seeds, d_model))

        # MAB for pooling
        self.mab = MultiHeadAttentionBlock(d_model, num_heads, dropout)

    def forward(self, X):
        """
        Forward pass through PMA.

        Args:
            X: Input set (batch, n_elements, d_model)

        Returns:
            Pooled representation (batch, num_seeds, d_model)
        """
        batch_size = X.shape[0]

        # Expand seed vectors for batch
        S = self.seed_vectors.expand(batch_size, -1, -1)

        # Attention-based pooling
        out = self.mab(S, X)

        return out


class SetTransformerEncoder(nn.Module):
    """
    Set Transformer Encoder.

    Stacks multiple ISAB layers to build deep set representations.
    Each layer allows information to flow between set elements through
    attention mechanisms.

    Args:
        d_model: Model dimension
        num_heads: Number of attention heads
        num_inds: Number of inducing points per ISAB
        num_layers: Number of ISAB layers
        dropout: Dropout probability
    """

    def __init__(self, d_model: int, num_heads: int, num_inds: int,
                 num_layers: int, dropout: float = 0.1):
        super().__init__()

        # Stack of ISAB layers
        self.layers = nn.ModuleList([
            InducedSetAttentionBlock(d_model, num_heads, num_inds, dropout)
            for _ in range(num_layers)
        ])

    def forward(self, X):
        """
        Forward pass through encoder.

        Args:
            X: Input set (batch, n_elements, d_model)

        Returns:
            Encoded set (batch, n_elements, d_model)
        """
        for layer in self.layers:
            X = layer(X)

        return X


class SetTransformerModel(nn.Module):
    """
    Complete Set Transformer architecture for ranking.

    This model processes a set of 5 active positions through:
    1. Input embedding layer
    2. Set Transformer Encoder (stacked ISABs)
    3. Pooling by Multihead Attention (PMA)
    4. Decoder (feed-forward network)
    5. Output layer (39 position scores)

    Args:
        input_dim: Input feature dimensionality per position
        d_model: Model dimension (embedding size)
        num_heads: Number of attention heads
        num_inds: Number of inducing points
        num_encoder_layers: Number of ISAB layers
        dim_feedforward: Feed-forward network dimension
        num_seeds: Number of seed vectors for pooling
        output_dim: Number of positions to rank (39)
        dropout: Dropout probability
    """

    def __init__(self, input_dim: int, d_model: int = 128, num_heads: int = 4,
                 num_inds: int = 16, num_encoder_layers: int = 2,
                 dim_feedforward: int = 256, num_seeds: int = 1,
                 output_dim: int = 39, dropout: float = 0.1):
        super().__init__()

        # Input embedding
        self.input_embedding = nn.Sequential(
            nn.Linear(input_dim, d_model),
            nn.ReLU(),
            nn.Dropout(dropout)
        )

        # Set Transformer Encoder
        self.encoder = SetTransformerEncoder(
            d_model=d_model,
            num_heads=num_heads,
            num_inds=num_inds,
            num_layers=num_encoder_layers,
            dropout=dropout
        )

        # Pooling
        self.pooling = PoolingByMultiheadAttention(
            d_model=d_model,
            num_heads=num_heads,
            num_seeds=num_seeds,
            dropout=dropout
        )

        # Decoder
        self.decoder = nn.Sequential(
            nn.Linear(d_model * num_seeds, dim_feedforward),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(dim_feedforward, dim_feedforward),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(dim_feedforward, output_dim)
        )

        self.num_seeds = num_seeds

    def forward(self, x):
        """
        Forward pass through Set Transformer.

        Args:
            x: Input features (batch, n_positions, input_dim)

        Returns:
            Position ranking scores (batch, output_dim)
        """
        # Embed input
        x = self.input_embedding(x)  # (batch, n_positions, d_model)

        # Encode set
        x = self.encoder(x)  # (batch, n_positions, d_model)

        # Pool to fixed size
        x = self.pooling(x)  # (batch, num_seeds, d_model)

        # Flatten pooled representation
        x = x.view(x.shape[0], -1)  # (batch, num_seeds * d_model)

        # Decode to position scores
        scores = self.decoder(x)  # (batch, output_dim)

        return scores


class SetTransformerRanker(BaseRanker):
    """
    Set Transformer ranker for advanced set-based ranking.

    Set Transformers use multi-head self-attention mechanisms to process sets,
    providing superior performance over DeepSets by learning complex interactions
    between elements. This architecture is state-of-the-art for set-based tasks.

    Why Set Transformers:
        - **Superior Performance**: Learns rich pairwise interactions via attention
        - **Interpretability**: Attention weights show which positions interact
        - **Scalability**: Efficient with inducing points (O(nm) vs O(n²))
        - **GPU Acceleration**: Batched attention operations leverage H200 GPUs

    Architecture Highlights:
        - Multi-head self-attention for complex pattern learning
        - Induced Set Attention Blocks (ISAB) for efficiency
        - Pooling by Multihead Attention (PMA) for aggregation
        - Deep feed-forward networks for non-linear transformations
        - Layer normalization and residual connections for training stability

    Args:
        params: Dict of hyperparameters (uses defaults if None)
        track_time: Whether to track training time (for RunPod decisions per NFR1)

    Attributes:
        model_: SetTransformerModel (set after fit())
        training_time_: float (total training time in seconds)
        epoch_times_: List[float] (per-epoch training times)
        train_losses_: List[float] (training losses per epoch)
        val_losses_: List[float] (validation losses per epoch)

    Example:
        >>> # Train with default hyperparameters
        >>> ranker = SetTransformerRanker()
        >>> ranker.fit(X_train, y_train)
        >>> predictions = ranker.predict_top_k(X_test, k=20)

        >>> # Custom hyperparameters for RunPod H200
        >>> ranker = SetTransformerRanker(params={
        ...     'd_model': 256,
        ...     'num_heads': 8,
        ...     'num_encoder_layers': 4,
        ...     'batch_size': 64,
        ...     'device': 'cuda'
        ... })
        >>> ranker.fit(X_train, y_train)

    Notes:
        - Requires PyTorch ≥2.0.0
        - GPU strongly recommended (set device='cuda' for RunPod H200)
        - More powerful than DeepSets but requires more computation
        - Training time tracked per epoch (NFR1 requirement)
    """

    def __init__(self, params: Optional[Dict[str, Any]] = None, track_time: bool = True):
        """
        Initialize Set Transformer ranker.

        Args:
            params: Hyperparameters (uses defaults if None)
            track_time: Whether to track training time

        Raises:
            ImportError: If PyTorch is not installed
        """
        super().__init__()

        # Check PyTorch availability
        if not TORCH_AVAILABLE:
            raise ImportError(
                "PyTorch is not installed. Please install it with:\n"
                "  pip install torch>=2.0.0\n"
                "See https://pytorch.org/get-started/locally/ for installation instructions."
            )

        # Set hyperparameters (merge with defaults)
        self.params = DEFAULT_SET_TRANSFORMER_PARAMS.copy()
        if params is not None:
            self.params.update(params)

        self.track_time = track_time

        # Set device (CPU or GPU)
        self.device = self.params['device']
        if self.device == 'cuda' and not torch.cuda.is_available():
            logger.warning("CUDA requested but not available. Falling back to CPU.")
            self.device = 'cpu'

        # Model and training artifacts (set during fit)
        self.model_: Optional[SetTransformerModel] = None
        self.input_dim_: Optional[int] = None
        self.training_time_: Optional[float] = None
        self.epoch_times_: Optional[list] = None
        self.train_losses_: Optional[list] = None
        self.val_losses_: Optional[list] = None
        self.best_epoch_: Optional[int] = None

    def fit(self, X_train: pd.DataFrame, y_train: Optional[pd.Series] = None):
        """
        Train the Set Transformer ranker on training data.

        This method:
        1. Validates input data
        2. Extracts active positions and prepares training data
        3. Creates Set Transformer model architecture
        4. Trains the model with early stopping
        5. Tracks training time per epoch (NFR1)

        Training Process:
            - Data is split into train/val (90/10) for early stopping
            - Model is trained to predict which positions are active
            - Binary cross-entropy loss for multi-label classification
            - Early stopping prevents overfitting
            - Best model (lowest val loss) is kept

        Args:
            X_train: Training features from imputed data
                Shape: (n_events, n_features)
                Expected: Imputed data from Epic 2 with position columns
            y_train: Not used (labels extracted from X_train)
                Kept for consistency with BaseRanker interface

        Returns:
            self: Returns self for method chaining

        Raises:
            ValueError: If X_train is empty or has wrong format
            RuntimeError: If training fails

        Notes:
            - Training time is logged per epoch if track_time=True
            - If total training exceeds 1 hour, suggests using RunPod (per NFR1)
        """
        # Validate input
        if X_train.empty:
            raise ValueError("X_train cannot be empty")

        if len(X_train) < 20:
            raise ValueError(
                f"X_train too small: {len(X_train)} samples. "
                "Need at least 20 samples for meaningful training."
            )

        logger.info(f"Training SetTransformerRanker on {len(X_train)} events...")

        # Start timing (if enabled)
        start_time = time.time() if self.track_time else None

        try:
            # Step 1: Extract active positions and prepare data
            X_tensor, y_tensor = self._prepare_training_data(X_train)

            # Step 2: Create train/val split for early stopping
            X_train_split, y_train_split, X_val, y_val = self._create_val_split(
                X_tensor, y_tensor
            )

            # Step 3: Create data loaders
            train_loader = self._create_dataloader(X_train_split, y_train_split, shuffle=True)
            val_loader = self._create_dataloader(X_val, y_val, shuffle=False)

            # Step 4: Initialize model
            self.input_dim_ = X_tensor.shape[2]  # Feature dimension per position
            self.model_ = SetTransformerModel(
                input_dim=self.input_dim_,
                d_model=self.params['d_model'],
                num_heads=self.params['num_heads'],
                num_inds=self.params['num_inds'],
                num_encoder_layers=self.params['num_encoder_layers'],
                dim_feedforward=self.params['dim_feedforward'],
                num_seeds=self.params['num_seeds'],
                output_dim=39,
                dropout=self.params['dropout']
            ).to(self.device)

            logger.info(f"Set Transformer architecture: d_model={self.params['d_model']}, "
                       f"num_heads={self.params['num_heads']}, "
                       f"num_encoder_layers={self.params['num_encoder_layers']}, "
                       f"num_inds={self.params['num_inds']}")
            logger.info(f"Device: {self.device}")

            # Step 5: Train model
            self._train_model(train_loader, val_loader)

            # Step 6: Track training time
            if self.track_time:
                self.training_time_ = time.time() - start_time
                logger.info(f"✓ Training completed in {self.training_time_:.2f} seconds")

                # Warn if training exceeded 1 hour (RunPod suggestion per NFR1)
                if self.training_time_ > 3600:
                    logger.warning(
                        f"⚠️ Training exceeded 1 hour ({self.training_time_/3600:.2f} hours). "
                        "Consider using RunPod H200 for Epic 5 experiments (see docs/architecture.md section 5)."
                    )

            self.is_fitted_ = True
            logger.info("✓ SetTransformerRanker training successful")

            return self

        except Exception as e:
            logger.error(f"Training failed: {e}")
            raise RuntimeError(
                f"SetTransformerRanker training failed: {e}. "
                "Check data format, hyperparameters, and available memory."
            ) from e

    def predict_top_k(self, X_test: pd.DataFrame, k: int = 20) -> np.ndarray:
        """
        Predict top-k ranked positions for each test event.

        For each test event:
        1. Prepare input features (5 active positions as set)
        2. Forward pass through Set Transformer model
        3. Rank all 39 positions by predicted scores
        4. Return top-k positions

        Args:
            X_test: Test features (same format as X_train)
                Shape: (n_events, n_features)
            k: Number of top predictions to return (default: 20)
                Must be in range [1, 39]

        Returns:
            predictions: Top-k ranked position predictions
                Shape: (n_events, k)
                Each row contains k position indices (1-39) ranked by likelihood

        Raises:
            RuntimeError: If called before fit()
            ValueError: If k not in range [1, 39]
            ValueError: If X_test has wrong format

        Example:
            >>> predictions = ranker.predict_top_k(X_test, k=20)
            >>> predictions.shape
            (1000, 20)  # 1000 test events, 20 predictions each
            >>> predictions[0]  # First event's top-20 predictions
            array([ 5, 12, 33, 7, 20, ...])
        """
        # Validation
        self._check_is_fitted()
        self._validate_k(k)

        if X_test.empty:
            raise ValueError("X_test cannot be empty")

        n_events = len(X_test)
        logger.info(f"Predicting top-{k} for {n_events} test events...")

        # Prepare test data
        X_test_tensor, _ = self._prepare_training_data(X_test)
        X_test_tensor = X_test_tensor.to(self.device)

        # Make predictions
        self.model_.eval()
        with torch.no_grad():
            scores = self.model_(X_test_tensor)  # (n_events, 39)
            scores = scores.cpu().numpy()

        # Rank positions by score (descending)
        ranked_indices = np.argsort(-scores, axis=1)

        # Convert 0-based indices to 1-based position numbers and take top-k
        predictions = ranked_indices[:, :k] + 1

        logger.info(f"✓ Predictions generated for {n_events} events")

        return predictions

    def _prepare_training_data(self, X: pd.DataFrame) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Prepare training data in Set Transformer format (DATA LEAKAGE FIX).

        Features for each position combine:
        - One-hot encoding (39-dim) - which position this is
        - Imputed features (learned patterns from Epic 2)

        CRITICAL: Does NOT use QV columns (they contain the answer!).
        Targets are extracted from q_1...q_5 columns.

        Returns:
            Tuple of (X_tensor, y_tensor):
                X_tensor: (n_samples, 5, input_dim) - 5 positions each with combined features
                y_tensor: (n_samples, 39) - binary labels for all positions
        """
        # Extract active positions from target columns (DATA LEAKAGE FIX)
        active_positions_list = self._extract_active_positions(X)

        # DATA LEAKAGE FIX: Get imputed feature columns (exclude targets and metadata only)
        # CRITICAL: QV columns are NOT in the data and should NOT be referenced
        # Only exclude target columns (q_*) and metadata (event-ID)
        position_cols = [f'q_{i}' for i in range(1, 6)]
        exclude_cols = set(position_cols + ['event-ID'])
        imputed_cols = [col for col in X.columns if col not in exclude_cols]

        n_samples = len(active_positions_list)

        X_list = []
        y_list = []

        for idx, (_, row) in enumerate(X.iterrows()):
            if idx >= len(active_positions_list):
                break

            positions = active_positions_list[idx]

            # Ensure exactly 5 positions (pad if needed)
            if len(positions) < 5:
                positions = positions + [0] * (5 - len(positions))
            elif len(positions) > 5:
                positions = positions[:5]

            # PATH A FIX: Extract imputed features for this event
            if len(imputed_cols) > 0:
                imputed_features = row[imputed_cols].values.astype(np.float32)
            else:
                imputed_features = np.array([], dtype=np.float32)

            # Create features for each position
            position_features = []
            for pos in positions:
                # One-hot encoding of position (39-dim) - which position this is
                onehot = np.zeros(39, dtype=np.float32)
                if pos > 0:
                    onehot[pos - 1] = 1.0

                # PATH A FIX: Combine one-hot with imputed features
                # This gives the model BOTH position identity AND learned patterns
                if len(imputed_features) > 0:
                    combined_features = np.concatenate([onehot, imputed_features])
                else:
                    combined_features = onehot

                position_features.append(combined_features)

            X_list.append(np.array(position_features))

            # Create target: binary labels for all 39 positions
            y_binary = np.zeros(39, dtype=np.float32)
            for pos in positions:
                if pos > 0:
                    y_binary[pos - 1] = 1.0
            y_list.append(y_binary)

        # Convert to tensors
        X_tensor = torch.tensor(np.array(X_list), dtype=torch.float32)
        y_tensor = torch.tensor(np.array(y_list), dtype=torch.float32)

        return X_tensor, y_tensor

    def _extract_active_positions(self, X: pd.DataFrame) -> list:
        """
        Extract active position indices from target columns (DATA LEAKAGE FIX).

        Uses q_1...q_5 columns which contain the 5 winning positions for each event.
        This replaces the previous approach that used QV columns (which contained
        the answer and caused data leakage).

        Args:
            X: Feature DataFrame with q_1, q_2, q_3, q_4, q_5 columns

        Returns:
            List of lists, each containing active position indices (1-39) for one event
            Example: [[8, 21, 22, 28, 38], [19, 29, 35, 37, 39], ...]

        Raises:
            ValueError: If target columns are missing

        Notes:
            - Target columns must contain winning positions (not binary indicators)
            - Position indices are 1-based (1 to 39)
            - DATA LEAKAGE FIX: Uses explicit targets, not QV feature columns
        """
        # Use explicit target columns (q_1 through q_5)
        target_cols = ['q_1', 'q_2', 'q_3', 'q_4', 'q_5']

        # Verify target columns exist
        missing_cols = [col for col in target_cols if col not in X.columns]
        if missing_cols:
            raise ValueError(
                f"Missing target columns in data. Expected q_1 through q_5. "
                f"Missing: {missing_cols}. "
                f"These columns should contain the 5 winning positions per event."
            )

        active_positions_list = []

        # Extract winning positions from target columns
        for _, row in X[target_cols].iterrows():
            # q_* columns contain position numbers (1-39)
            positions = [int(row[col]) for col in target_cols]
            active_positions_list.append(positions)

        return active_positions_list

    def _create_val_split(self, X: torch.Tensor, y: torch.Tensor,
                          val_ratio: float = 0.1) -> Tuple[torch.Tensor, ...]:
        """Create train/validation split for early stopping."""
        n_samples = X.shape[0]
        n_val = int(n_samples * val_ratio)
        n_train = n_samples - n_val

        X_train = X[:n_train]
        y_train = y[:n_train]
        X_val = X[n_train:]
        y_val = y[n_train:]

        logger.info(f"Train/val split: {n_train}/{n_val} samples")

        return X_train, y_train, X_val, y_val

    def _create_dataloader(self, X: torch.Tensor, y: torch.Tensor,
                           shuffle: bool = True) -> DataLoader:
        """Create PyTorch DataLoader for batching."""
        dataset = TensorDataset(X, y)
        loader = DataLoader(
            dataset,
            batch_size=self.params['batch_size'],
            shuffle=shuffle
        )
        return loader

    def _train_model(self, train_loader: DataLoader, val_loader: DataLoader):
        """Train Set Transformer model with early stopping."""
        # Loss function
        criterion = nn.BCEWithLogitsLoss()

        # Optimizer
        optimizer = optim.Adam(
            self.model_.parameters(),
            lr=self.params['learning_rate'],
            weight_decay=self.params['weight_decay']
        )

        # Early stopping
        best_val_loss = float('inf')
        patience_counter = 0
        patience = self.params['early_stopping_patience']

        # Training history
        self.train_losses_ = []
        self.val_losses_ = []
        self.epoch_times_ = []

        logger.info(f"Starting training for up to {self.params['epochs']} epochs...")

        for epoch in range(self.params['epochs']):
            epoch_start = time.time() if self.track_time else None

            # Training phase
            self.model_.train()
            train_loss = 0.0
            for X_batch, y_batch in train_loader:
                X_batch = X_batch.to(self.device)
                y_batch = y_batch.to(self.device)

                outputs = self.model_(X_batch)
                loss = criterion(outputs, y_batch)

                optimizer.zero_grad()
                loss.backward()
                optimizer.step()

                train_loss += loss.item() * X_batch.size(0)

            train_loss /= len(train_loader.dataset)
            self.train_losses_.append(train_loss)

            # Validation phase
            self.model_.eval()
            val_loss = 0.0
            with torch.no_grad():
                for X_batch, y_batch in val_loader:
                    X_batch = X_batch.to(self.device)
                    y_batch = y_batch.to(self.device)

                    outputs = self.model_(X_batch)
                    loss = criterion(outputs, y_batch)

                    val_loss += loss.item() * X_batch.size(0)

            val_loss /= len(val_loader.dataset)
            self.val_losses_.append(val_loss)

            # Track epoch time
            if self.track_time:
                epoch_time = time.time() - epoch_start
                self.epoch_times_.append(epoch_time)

            # Log progress
            if (epoch + 1) % 10 == 0 or epoch == 0:
                logger.info(f"Epoch {epoch+1}/{self.params['epochs']}: "
                           f"train_loss={train_loss:.4f}, val_loss={val_loss:.4f}")

            # Early stopping check
            if val_loss < best_val_loss:
                best_val_loss = val_loss
                self.best_epoch_ = epoch + 1
                patience_counter = 0
                self.best_model_state_ = self.model_.state_dict().copy()
            else:
                patience_counter += 1

            if patience_counter >= patience:
                logger.info(f"Early stopping triggered at epoch {epoch+1}")
                logger.info(f"Best validation loss: {best_val_loss:.4f} at epoch {self.best_epoch_}")
                break

        # Restore best model
        self.model_.load_state_dict(self.best_model_state_)
        logger.info(f"✓ Training completed. Best epoch: {self.best_epoch_}")

    def save_model(self, model_path: Path, save_metadata: bool = True):
        """Save trained model to disk."""
        self._check_is_fitted()

        model_path = Path(model_path)
        model_path.parent.mkdir(parents=True, exist_ok=True)

        logger.info(f"Saving model to {model_path}")
        torch.save({
            'model_state_dict': self.model_.state_dict(),
            'params': self.params,
            'input_dim': self.input_dim_
        }, model_path)
        logger.info(f"✓ Model saved successfully")

        if save_metadata:
            metadata_path = Path(str(model_path) + '.meta.json')
            metadata = {
                'ranker_type': 'set_transformer',
                'pytorch_version': torch.__version__,
                'hyperparameters': self.params,
                'training_time_seconds': self.training_time_,
                'total_epochs_trained': len(self.train_losses_),
                'best_epoch': self.best_epoch_,
                'best_val_loss': self.val_losses_[self.best_epoch_ - 1] if self.best_epoch_ else None,
                'final_train_loss': self.train_losses_[-1] if self.train_losses_ else None,
                'timestamp': pd.Timestamp.now().isoformat()
            }

            logger.info(f"Saving metadata to {metadata_path}")
            with open(metadata_path, 'w') as f:
                json.dump(metadata, f, indent=2)
            logger.info(f"✓ Metadata saved successfully")

    @classmethod
    def load_model(cls, model_path: Path) -> 'SetTransformerRanker':
        """Load trained model from disk."""
        model_path = Path(model_path)

        if not model_path.exists():
            raise FileNotFoundError(
                f"Model file not found: {model_path}. "
                "Please train and save model first using save_model()."
            )

        logger.info(f"Loading model from {model_path}")
        checkpoint = torch.load(model_path, map_location='cpu')

        instance = cls(params=checkpoint['params'])
        instance.input_dim_ = checkpoint['input_dim']
        instance.model_ = SetTransformerModel(
            input_dim=instance.input_dim_,
            d_model=instance.params['d_model'],
            num_heads=instance.params['num_heads'],
            num_inds=instance.params['num_inds'],
            num_encoder_layers=instance.params['num_encoder_layers'],
            dim_feedforward=instance.params['dim_feedforward'],
            num_seeds=instance.params['num_seeds'],
            output_dim=39,
            dropout=instance.params['dropout']
        )

        instance.model_.load_state_dict(checkpoint['model_state_dict'])
        instance.model_.to(instance.device)
        instance.is_fitted_ = True

        # Try to load metadata
        metadata_path = Path(str(model_path) + '.meta.json')
        if metadata_path.exists():
            with open(metadata_path, 'r') as f:
                metadata = json.load(f)
                instance.training_time_ = metadata.get('training_time_seconds')
                instance.best_epoch_ = metadata.get('best_epoch')
                logger.info("✓ Metadata loaded")

        logger.info(f"✓ Model loaded successfully")
        return instance

    def __repr__(self) -> str:
        """String representation with training status and time."""
        fitted_status = "fitted" if self.is_fitted_ else "not fitted"
        if self.training_time_ is not None:
            return f"SetTransformerRanker({fitted_status}, trained in {self.training_time_:.2f}s, best_epoch={self.best_epoch_})"
        else:
            return f"SetTransformerRanker({fitted_status})"
