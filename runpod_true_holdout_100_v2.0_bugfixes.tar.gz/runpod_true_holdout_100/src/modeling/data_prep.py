"""
Data Preparation for Ranking Models

This module provides utilities for preparing data for training ranking models.
The primary function is to split imputed datasets into training and holdout sets
while maintaining strict temporal ordering to prevent data leakage.

Key Functions:
    - prepare_sequential_split(): Split data temporally (train → holdout)
    - validate_split(): Verify no data leakage between splits
    - save_split_metadata(): Log split statistics

Author: BMad Dev Agent (James)
Date: 2025-10-13
Story: Epic 3, Story 3.1 - Data Preparation Script
"""

import json
import logging
from pathlib import Path
from typing import Tuple, Dict, Any, Optional
import pandas as pd
import numpy as np

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def prepare_sequential_split(
    data_path: Path,
    train_ratio: float = 0.8,
    output_dir: Path = Path("data/processed/"),
    save_splits: bool = True
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    Split dataset into training and holdout sets maintaining temporal order.

    This function ensures NO DATA LEAKAGE by enforcing that all training
    events occur before all holdout events. This is critical for time-series
    prediction tasks where we want to simulate real-world sequential prediction.

    The split is performed by:
    1. Loading the imputed dataset
    2. Calculating split point based on train_ratio
    3. Taking first train_ratio% of data as training
    4. Taking remaining data as holdout
    5. Validating no overlap or leakage
    6. Optionally saving splits to disk

    Args:
        data_path: Path to imputed Parquet file (from Epic 2)
        train_ratio: Fraction of data to use for training (default: 0.8)
                    Must be in range (0, 1)
        output_dir: Directory to save split datasets (default: data/processed/)
        save_splits: Whether to save splits to disk (default: True)

    Returns:
        Tuple of (train_df, holdout_df) as pandas DataFrames

    Raises:
        FileNotFoundError: If data_path does not exist
        ValueError: If train_ratio not in (0, 1)
        RuntimeError: If split validation fails (data leakage detected)

    Example:
        >>> train_df, holdout_df = prepare_sequential_split(
        ...     Path("data/processed/imputed_basis.parquet"),
        ...     train_ratio=0.8
        ... )
        >>> print(f"Train: {len(train_df)}, Holdout: {len(holdout_df)}")
        Train: 9264, Holdout: 2317

    Notes:
        - The split is deterministic (always produces same result for same input)
        - event-ID column is preserved in both splits
        - All feature columns are preserved
        - Split metadata is saved as JSON sidecar file
    """
    # Validate inputs
    logger.info(f"Loading data from {data_path}")

    if not data_path.exists():
        raise FileNotFoundError(
            f"Imputed data not found at {data_path}. "
            "Please run imputation first (Epic 2, Story 2.7). "
            f"Expected file: {data_path.absolute()}"
        )

    if not (0 < train_ratio < 1):
        raise ValueError(
            f"train_ratio must be in range (0, 1), got {train_ratio}. "
            "Common values: 0.7 (70/30 split), 0.8 (80/20 split), 0.9 (90/10 split)"
        )

    # Load dataset
    try:
        df = pd.read_parquet(data_path)
        logger.info(f"Loaded {len(df)} samples with {len(df.columns)} columns")
    except Exception as e:
        raise RuntimeError(
            f"Failed to load Parquet file: {e}. "
            "Ensure the file is a valid Parquet file created by Epic 2 imputation."
        )

    # Validate dataset structure
    if 'event-ID' not in df.columns:
        raise ValueError(
            "Dataset missing 'event-ID' column. "
            "Expected imputed dataset from Epic 2 with event-ID preserved."
        )

    if len(df) < 10:
        raise ValueError(
            f"Dataset too small for meaningful split: {len(df)} samples. "
            "Need at least 10 samples for train/holdout split."
        )

    # Calculate split point
    # Use floor division to ensure we get exact split
    n_train = int(len(df) * train_ratio)
    n_holdout = len(df) - n_train

    logger.info(f"Splitting dataset: {n_train} train / {n_holdout} holdout ({train_ratio:.1%}/{1-train_ratio:.1%})")

    # Perform sequential split
    # CRITICAL: Using .iloc to maintain original order (temporal ordering)
    # First n_train samples → training
    # Remaining samples → holdout
    train_df = df.iloc[:n_train].copy()
    holdout_df = df.iloc[n_train:].copy()

    # Reset indices to 0-based for consistency
    # This ensures loaded splits match the split DataFrames
    train_df.reset_index(drop=True, inplace=True)
    holdout_df.reset_index(drop=True, inplace=True)

    # Validate split integrity
    logger.info("Validating split integrity (checking for data leakage)...")
    is_valid, validation_msg = validate_split(train_df, holdout_df, df)

    if not is_valid:
        raise RuntimeError(
            f"Split validation failed: {validation_msg}. "
            "This indicates data leakage or corruption. "
            "Please check the input data."
        )

    logger.info(f"✓ Split validation passed: {validation_msg}")

    # Save splits if requested
    if save_splits:
        output_dir.mkdir(parents=True, exist_ok=True)

        train_path = output_dir / "train_split.parquet"
        holdout_path = output_dir / "holdout_split.parquet"

        logger.info(f"Saving training split to {train_path}")
        train_df.to_parquet(train_path, index=False)

        logger.info(f"Saving holdout split to {holdout_path}")
        holdout_df.to_parquet(holdout_path, index=False)

        # Save metadata
        metadata = create_split_metadata(
            data_path=data_path,
            train_df=train_df,
            holdout_df=holdout_df,
            train_ratio=train_ratio
        )

        metadata_path = output_dir / "split_metadata.json"
        logger.info(f"Saving split metadata to {metadata_path}")
        with open(metadata_path, 'w') as f:
            json.dump(metadata, f, indent=2)

        logger.info(f"✓ Splits saved successfully to {output_dir}")

    return train_df, holdout_df


def validate_split(
    train_df: pd.DataFrame,
    holdout_df: pd.DataFrame,
    original_df: Optional[pd.DataFrame] = None
) -> Tuple[bool, str]:
    """
    Validate train/holdout split for temporal integrity and no data leakage.

    Performs comprehensive validation checks:
    1. No overlap: Training and holdout event IDs are disjoint
    2. Temporal ordering: All training event IDs < all holdout event IDs
    3. Completeness: All original samples present in exactly one split
    4. No duplicates: No event ID appears multiple times within a split

    Args:
        train_df: Training DataFrame
        holdout_df: Holdout DataFrame
        original_df: Original DataFrame before split (optional, for completeness check)

    Returns:
        Tuple of (is_valid: bool, message: str)
        - is_valid: True if all validation checks pass
        - message: Description of validation result or failure reason

    Example:
        >>> is_valid, msg = validate_split(train_df, holdout_df, df)
        >>> if not is_valid:
        ...     print(f"Validation failed: {msg}")
    """
    # Check 1: No overlap in event IDs
    train_ids = set(train_df['event-ID'])
    holdout_ids = set(holdout_df['event-ID'])
    overlap = train_ids.intersection(holdout_ids)

    if overlap:
        return False, f"Data leakage detected: {len(overlap)} event IDs present in both train and holdout"

    # Check 2: Temporal ordering (train IDs < holdout IDs)
    train_max_id = train_df['event-ID'].max()
    holdout_min_id = holdout_df['event-ID'].min()

    if train_max_id >= holdout_min_id:
        return False, (
            f"Temporal ordering violated: max train ID ({train_max_id}) >= "
            f"min holdout ID ({holdout_min_id}). This indicates data leakage."
        )

    # Check 3: Completeness (if original provided)
    if original_df is not None:
        original_ids = set(original_df['event-ID'])
        split_ids = train_ids.union(holdout_ids)

        if split_ids != original_ids:
            missing = original_ids - split_ids
            extra = split_ids - original_ids
            return False, (
                f"Split completeness check failed: "
                f"{len(missing)} IDs missing from splits, "
                f"{len(extra)} extra IDs in splits"
            )

    # Check 4: No duplicates within splits
    train_dups = len(train_df) - len(train_ids)
    holdout_dups = len(holdout_df) - len(holdout_ids)

    if train_dups > 0 or holdout_dups > 0:
        return False, (
            f"Duplicate event IDs detected: "
            f"{train_dups} duplicates in train, {holdout_dups} in holdout"
        )

    # All checks passed
    message = (
        f"Temporal integrity verified: "
        f"{len(train_df)} train samples (max ID: {train_max_id}), "
        f"{len(holdout_df)} holdout samples (min ID: {holdout_min_id}), "
        f"no overlap, no leakage"
    )
    return True, message


def create_split_metadata(
    data_path: Path,
    train_df: pd.DataFrame,
    holdout_df: pd.DataFrame,
    train_ratio: float
) -> Dict[str, Any]:
    """
    Create metadata dictionary describing the train/holdout split.

    This metadata is useful for:
    - Reproducibility: Track exact split configuration
    - Debugging: Verify split statistics
    - Documentation: Understand split characteristics

    Args:
        data_path: Path to original imputed data file
        train_df: Training DataFrame
        holdout_df: Holdout DataFrame
        train_ratio: Train ratio used for split

    Returns:
        Dictionary with split metadata including:
        - input_file: Path to original imputed data
        - split_method: 'sequential' (temporal ordering)
        - train_ratio: Configured train ratio
        - train_size: Number of training samples
        - holdout_size: Number of holdout samples
        - train_id_range: [min, max] event IDs in train
        - holdout_id_range: [min, max] event IDs in holdout
        - feature_count: Number of feature columns (excludes event-ID)
        - timestamp: ISO format timestamp of split creation

    Example:
        >>> metadata = create_split_metadata(path, train_df, holdout_df, 0.8)
        >>> print(f"Train size: {metadata['train_size']}")
        Train size: 9264
    """
    metadata = {
        "input_file": str(data_path),
        "split_method": "sequential",
        "train_ratio": train_ratio,
        "train_size": len(train_df),
        "holdout_size": len(holdout_df),
        "train_id_range": [
            int(train_df['event-ID'].min()),
            int(train_df['event-ID'].max())
        ],
        "holdout_id_range": [
            int(holdout_df['event-ID'].min()),
            int(holdout_df['event-ID'].max())
        ],
        "feature_count": len(train_df.columns) - 1,  # Exclude event-ID
        "timestamp": pd.Timestamp.now().isoformat()
    }

    return metadata


def load_split_data(data_dir: Path = Path("data/processed/")) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    Load previously saved train/holdout splits from disk.

    Convenience function to load splits without re-running the split process.
    Useful for:
    - Training models on consistent splits
    - Resuming interrupted workflows
    - Ensemble training on same data

    Args:
        data_dir: Directory containing saved splits (default: data/processed/)

    Returns:
        Tuple of (train_df, holdout_df)

    Raises:
        FileNotFoundError: If split files don't exist

    Example:
        >>> train_df, holdout_df = load_split_data()
        >>> print(f"Loaded {len(train_df)} train samples")
        Loaded 9264 train samples
    """
    train_path = data_dir / "train_split.parquet"
    holdout_path = data_dir / "holdout_split.parquet"

    if not train_path.exists() or not holdout_path.exists():
        raise FileNotFoundError(
            f"Split files not found in {data_dir}. "
            "Please run prepare_sequential_split() first to generate splits. "
            f"Expected files: {train_path}, {holdout_path}"
        )

    logger.info(f"Loading training split from {train_path}")
    train_df = pd.read_parquet(train_path)

    logger.info(f"Loading holdout split from {holdout_path}")
    holdout_df = pd.read_parquet(holdout_path)

    logger.info(f"Loaded splits: {len(train_df)} train, {len(holdout_df)} holdout")

    return train_df, holdout_df
