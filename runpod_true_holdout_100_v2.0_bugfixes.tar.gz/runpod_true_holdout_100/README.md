# RunPod TRUE Holdout Test - Version 2.0

## 🚀 Quick Start

**Read this first**: `RUNPOD_QUICKSTART.md` - Complete setup and usage guide

**TL;DR**:
```bash
pip install -r requirements.txt
bash RUN_TEST.sh
```

---

## 🎯 What This Package Does

Runs a TRUE holdout test on 100 events (or specified count) using 4 quantum imputation models with **FIXED** position-aware feature extraction.

**TRUE Holdout**: For each test event N, train only on events 1 to N-1, predict N without seeing results.

**Models**:
1. Amplitude Embedding (377 features)
2. Angle Encoding (322 features)
3. Graph/Cycle Encoding (277 features)
4. Density Matrix (259 features)

**Ensemble**: Simple majority voting across all 4 models.

---

## ⚠️ CRITICAL: Bug Fixes Included (v2.0)

This package includes fixes for **TWO CRITICAL BUGS** discovered 2025-10-28:

### Bug #1: Event-Level Feature Copying
**Problem**: All 39 positions got identical event-level features
**Fix**: New `LGBMRankerPositionAware` extracts position-specific quantum features
**Impact**: Models now use actual quantum patterns (amplitude[P], probability[P], etc.)

### Bug #2: Missing Training Labels
**Problem**: q_1 through q_5 columns all set to 0 (no training signal)
**Fix**: Extract actual winning positions from QV_* binary indicators
**Impact**: Models now learn properly (feature importances non-zero)

### Validation Status: ✅ FIXED

- ✅ All 4 models produce DIFFERENT predictions
- ✅ Feature importances NON-ZERO (200-400 range)
- ✅ Position-specific quantum features top-ranked
- ✅ 100% recall@20 on validation tests

**Read more**: `BUGS_FIXED_VALIDATED_2025-10-28.md`

---

## 📦 Package Contents

```
runpod_true_holdout_100/
├── README.md (this file)
├── RUNPOD_QUICKSTART.md (detailed guide)
├── RUN_TEST.sh (convenience script)
├── requirements.txt
├── true_holdout_test_100_optimized.py (main script)
├── BUG_FIX_SUMMARY_2025-10-28.md (technical details)
├── BUGS_FIXED_VALIDATED_2025-10-28.md (executive summary)
├── src/
│   ├── imputation/ (4 quantum imputation methods + proximity features)
│   └── modeling/
│       ├── data_prep.py
│       └── rankers/
│           ├── lgbm_ranker.py
│           ├── lgbm_ranker_position_aware.py [NEW - BUG FIX]
│           └── position_feature_extractor.py [NEW - BUG FIX]
└── data/
    └── raw/
        └── c5_Matrix.csv (11,589 events)
```

---

## 🖥️ Hardware Requirements

**Optimized for**:
- 16 vCPUs @ 5+ GHz
- 32-64 GB RAM (DDR5 preferred)
- 50+ GB NVMe storage

**Minimum**:
- 16 vCPUs
- 32 GB RAM
- 50 GB storage

---

## 📊 Expected Performance

| Metric | Expected Value |
|--------|---------------|
| **Runtime** | ~3 min per event (100 events = 5 hours) |
| **Recall@20** | 80-100% per model |
| **Ensemble Recall** | 85-95% average |
| **Memory Peak** | ~0.3 GB per event |
| **Feature Importances** | Non-zero (200-400 range) |
| **Model Diversity** | All 4 models DIFFERENT |

**Before vs After Fixes**:

| Metric | Before (Buggy) | After (Fixed) |
|--------|----------------|---------------|
| Feature Importances | 0.00 (all) | 200-400 |
| Predictions | Identical | Different |
| Recall@20 | 44% | 80-100% |

---

## 🏃 Running the Test

### Option 1: Interactive Script (Recommended)
```bash
bash RUN_TEST.sh
# Follow prompts to select:
#   1) Full 100-event test (~5 hours)
#   2) Quick 5-event validation (~15 minutes)
#   3) Single event test (~3 minutes)
#   4) Custom number of events
```

### Option 2: Direct Python
```bash
# Full test
python true_holdout_test_100_optimized.py --num-events 100

# Quick validation
python true_holdout_test_100_optimized.py --num-events 5

# Single event
python true_holdout_test_100_optimized.py --num-events 1
```

---

## 📁 Output Files

### Main Results
- `reports/true_holdout_100/aggregate_results.json` - Overall statistics
- `reports/true_holdout_100/checkpoint.json` - Detailed per-event results

### Resume Capability
- Script saves progress after each event
- Safe to Ctrl+C and restart
- Will resume from last completed event

---

## 🔍 Monitoring Progress

### Real-Time Output
```
================================================================================
Event 11490 (1/100)
================================================================================
  Event Duration: 178.3s
  Model Training Times:
    amplitude: train=152.7s, total=175.0s
    angle_encoding: train=139.3s, total=161.7s
  Memory Peak: 0.32 GB
  Recalls: amplitude: 100%, angle_encoding: 100%, ...
  [CHECKPOINT] Saved
```

### System Monitoring
```bash
# In another terminal
watch -n 5 "ps aux | grep python && free -h"
```

---

## ✅ Verification Checklist

**Before running full 100-event test**:

1. ✅ Verify dependencies installed:
   ```bash
   python -c "import numpy, pandas, lightgbm, sklearn, scipy, psutil; print('OK')"
   ```

2. ✅ Verify data file:
   ```bash
   wc -l data/raw/c5_Matrix.csv
   # Should show: 11590 (11589 events + 1 header)
   ```

3. ✅ Verify hardware:
   ```bash
   nproc  # Should show: 16
   free -h  # Should show: 32GB+ total
   ```

4. ✅ Run quick validation:
   ```bash
   python true_holdout_test_100_optimized.py --num-events 1
   # Should complete in ~3 minutes with non-zero feature importances
   ```

5. ✅ Check for bug fixes:
   ```bash
   grep "LGBMRankerPositionAware" true_holdout_test_100_optimized.py
   # Should find imports and usage (confirms v2.0 with fixes)
   ```

---

## 🐛 Troubleshooting

### Common Issues

**"All feature importances are 0.00"**
- **Cause**: Old buggy code
- **Fix**: Verify `LGBMRankerPositionAware` is being used

**"Out of memory"**
- **Cause**: Insufficient RAM
- **Fix**: Use smaller batches or more RAM

**"Slow performance (>5 min per event)"**
- **Cause**: Insufficient CPUs
- **Fix**: Ensure 16+ vCPU instance

**"Module not found"**
- **Cause**: Missing dependencies
- **Fix**: `pip install -r requirements.txt`

See `RUNPOD_QUICKSTART.md` for detailed troubleshooting.

---

## 📈 Results Interpretation

### Good Performance Indicators
- ✅ Mean recall@20: 80-95%
- ✅ Ensemble > individual models
- ✅ Feature importances: 200-400 (non-zero)
- ✅ Models show DIFFERENT predictions
- ✅ Top features: tunneling, min_distance, quantum features

### Red Flags
- ❌ All models identical → Bug still present
- ❌ Feature importances = 0.00 → Training labels issue
- ❌ Mean recall < 50% → Model not learning

---

## 📥 Downloading Results

```bash
cd reports/true_holdout_100
tar -czf results_$(date +%Y%m%d).tar.gz *.json
# Download via RunPod web interface or scp
```

---

## 📚 Documentation

- **`RUNPOD_QUICKSTART.md`** - Complete setup and usage guide
- **`BUGS_FIXED_VALIDATED_2025-10-28.md`** - Executive summary of bug fixes
- **`BUG_FIX_SUMMARY_2025-10-28.md`** - Technical details of bugs and fixes

---

## 🔧 Technical Details

### Parallel Execution
- 4 models train simultaneously (1 process per model)
- Each model uses 4 threads for LightGBM
- Total: 4 processes × 4 threads = **16 vCPUs fully utilized**

### Memory Usage
- Peak: ~0.3 GB during model training
- Baseline: ~0.25 GB for data loading
- Safe for 32GB RAM (~10% utilization)

### Imputation Methods

| Method | Features | Key Concepts |
|--------|----------|-------------|
| Amplitude | 377 | Quantum amplitudes, probabilities, interference |
| Angle | 322 | Angular mapping, trigonometric features, C₃₉ symmetry |
| Graph/Cycle | 277 | DFT harmonics, graph distances, cyclic patterns |
| Density Matrix | 259 | Quantum density elements, mixed states |

All methods include 199 position-specific proximity features (tunneling, min_distance, density_windows).

---

## 📞 Support

**Issues?**
1. Check `RUNPOD_QUICKSTART.md` for detailed troubleshooting
2. Review logs for error messages
3. Verify bug fixes applied (check for `LGBMRankerPositionAware`)
4. Read technical details in `BUG_FIX_SUMMARY_2025-10-28.md`

---

## 📝 Version History

**v2.0 (2025-10-28)** - Bug Fixes Applied
- ✅ Fixed event-level feature copying (position-aware ranker)
- ✅ Fixed missing training labels (q_* columns)
- ✅ Validated: All 4 models now different with proper features
- ✅ Production ready for TRUE holdout testing

**v1.0** - Initial release (buggy)
- ❌ All models identical
- ❌ Feature importances = 0.00
- ❌ Not production ready

---

**Package Version**: 2.0 (Bug Fixes Applied)
**Created**: 2025-10-28
**Author**: BMad Dev Team
**Status**: ✅ Production Ready
