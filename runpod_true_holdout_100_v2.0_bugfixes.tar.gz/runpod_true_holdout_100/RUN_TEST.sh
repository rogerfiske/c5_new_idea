#!/bin/bash
# RunPod TRUE Holdout Test - Convenience Script
# Version 2.0 - Bug Fixes Applied (2025-10-28)

echo "================================================================================"
echo "RunPod TRUE Holdout Test - Quick Start"
echo "================================================================================"
echo ""
echo "Hardware Check:"
echo "  CPUs: $(nproc)"
echo "  RAM: $(free -h | grep Mem | awk '{print $2}')"
echo "  Disk: $(df -h . | tail -1 | awk '{print $4}' | head -c 10) available"
echo ""

# Verify Python and packages
echo "Checking Python environment..."
python3 --version || { echo "ERROR: Python 3 not found"; exit 1; }

echo "Checking required packages..."
python3 -c "import numpy, pandas, lightgbm, sklearn, scipy, psutil" 2>/dev/null || {
    echo "ERROR: Missing packages. Installing..."
    pip install -r requirements.txt
}

echo ""
echo "✓ Environment ready"
echo ""

# Check data file
if [ ! -f "data/raw/c5_Matrix.csv" ]; then
    echo "ERROR: data/raw/c5_Matrix.csv not found!"
    exit 1
fi

echo "Data file verified: $(wc -l < data/raw/c5_Matrix.csv) lines"
echo ""

# Ask user for test type
echo "Select test type:"
echo "  1) Full 100-event test (~5 hours)"
echo "  2) Quick 5-event validation (~15 minutes)"
echo "  3) Single event test (~3 minutes)"
echo "  4) Custom (specify number of events)"
echo ""
read -p "Enter choice (1-4): " choice

case $choice in
    1)
        NUM_EVENTS=100
        echo ""
        echo "Running FULL 100-event test..."
        echo "Expected time: ~5 hours"
        ;;
    2)
        NUM_EVENTS=5
        echo ""
        echo "Running 5-event validation..."
        echo "Expected time: ~15 minutes"
        ;;
    3)
        NUM_EVENTS=1
        echo ""
        echo "Running single event test..."
        echo "Expected time: ~3 minutes"
        ;;
    4)
        read -p "Enter number of events (1-100): " NUM_EVENTS
        if ! [[ "$NUM_EVENTS" =~ ^[0-9]+$ ]] || [ "$NUM_EVENTS" -lt 1 ] || [ "$NUM_EVENTS" -gt 100 ]; then
            echo "ERROR: Invalid number. Must be 1-100."
            exit 1
        fi
        echo ""
        echo "Running $NUM_EVENTS-event test..."
        ;;
    *)
        echo "Invalid choice. Exiting."
        exit 1
        ;;
esac

echo ""
echo "================================================================================"
echo "Starting test at $(date)"
echo "================================================================================"
echo ""
echo "Progress will be saved to: reports/true_holdout_100/checkpoint.json"
echo "Safe to Ctrl+C and resume later"
echo ""

# Run the test
python3 true_holdout_test_100_optimized.py --num-events $NUM_EVENTS

EXIT_CODE=$?

echo ""
echo "================================================================================"
echo "Test completed at $(date)"
echo "Exit code: $EXIT_CODE"
echo "================================================================================"
echo ""

if [ $EXIT_CODE -eq 0 ]; then
    echo "✓ Test completed successfully!"
    echo ""
    echo "Results saved to: reports/true_holdout_100/"
    echo ""
    echo "To view aggregate results:"
    echo "  cat reports/true_holdout_100/aggregate_results.json | python3 -m json.tool"
    echo ""
    echo "To download results:"
    echo "  cd reports/true_holdout_100"
    echo "  tar -czf results_$(date +%Y%m%d).tar.gz *.json"
else
    echo "✗ Test failed with exit code: $EXIT_CODE"
    echo ""
    echo "Check for errors above"
    echo "Checkpoint saved - safe to resume"
fi

echo ""
