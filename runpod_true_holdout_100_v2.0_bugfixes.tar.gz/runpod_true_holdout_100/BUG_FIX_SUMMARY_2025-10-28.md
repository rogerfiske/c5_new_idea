# Critical Bug Fixes - 2025-10-28

## Issue Discovered
All 4 quantum imputation models (Amplitude, Angle Encoding, Graph/Cycle, Density Matrix) were producing **IDENTICAL** predictions, making ensemble voting meaningless.

## Root Causes Found

### Bug #1: Event-Level Feature Copying
**Problem**: The `LGBMRanker` was copying the same event-level feature vector to all 39 candidate positions, only varying `position_id` and `position_frequency`. The quantum imputation features weren't being used to distinguish between positions!

**Example**: For Amplitude Embedding which creates 377 features:
- 39 position amplitudes
- 39 position probabilities
- 96 interference terms
- 4 entanglement measures
- 199 proximity features (position-specific)

The ranker was copying ALL 377 features identically to all 39 positions, so position 1 and position 39 had the exact same amplitude, probability, and proximity values!

**Fix Created**:
1. `src/modeling/rankers/position_feature_extractor.py` - New class to extract position-specific features from event-level vectors
2. `src/modeling/rankers/lgbm_ranker_position_aware.py` - New ranker class extending LGBMRanker with proper feature extraction

**Feature Extraction Logic**:
- **Amplitude**: Extract position-specific amplitude[pos], probability[pos], and proximity features for that position
- **Angle**: Extract position-specific angle[pos], sin/cos[pos], and proximity features
- **Graph/Cycle**: Extract event-level DFT/graph context + position-specific proximity features
- **Density**: Extract event-level density context + position-specific proximity features

### Bug #2: Missing Training Labels
**Problem**: The q_1 through q_5 columns (which contain the 5 winning positions per event) were being set to ALL ZEROS instead of actual winning positions!

**Impact**: LightGBM thought every training event had winners [0, 0, 0, 0, 0], which is invalid. The model couldn't learn anything, resulting in:
- All feature importances = 0.00
- Random/meaningless predictions
- Identical outputs across all models

**Fix Applied**:
- Extract winning positions from QV_* columns (binary indicators)
- Populate q_1 through q_5 with actual position indices (1-39)

**Fixed in**:
- `production/true_holdout_test_100_optimized.py`
- `simple_model_diff_test.py`

## Evidence of Fix

### Before Fix
- Feature importance: ALL ZEROS
- Predictions: All 4 models identical
- Example: All predicted [1, 20, 21-38] for event 11589

### After Fix
- Feature importance: NON-ZERO with position-specific features ranked high!
  - Amplitude: tunneling (249), position_id (165), min_distance (83)
  - Angle: position_id (156), aggregate_0 (84), tunneling (78)
  - Graph: tunneling (258), min_distance (173), density_window_0 (82)
  - Density: tunneling (284), density_window_0 (139), min_distance (132)

- Predictions: All 4 models DIFFERENT!
  - Amplitude: [7, 9, 10, 11, 12, 13, 16, 17, 19, 21, 23, 25, 28, 31, 32, 33, 35, 36, 37, 38]
  - Angle: [1, 2, 3, 5, 8, 10, 12, 13, 14, 17, 19, 21, 22, 23, 29, 33, 35, 37, 38, 39]
  - Graph: [3, 5, 6, 19, 21, 22, 23, 24, 25, 26, 27, 28, 29, 33, 34, 35, 36, 37, 38, 39]
  - Density: [2, 3, 6, 19, 21, 22, 23, 24, 25, 26, 27, 28, 29, 33, 34, 35, 36, 37, 38, 39]

## Files Modified

### New Files Created
1. `src/modeling/rankers/position_feature_extractor.py` - Position-specific feature extraction
2. `src/modeling/rankers/lgbm_ranker_position_aware.py` - Fixed ranker with proper features
3. `simple_model_diff_test.py` - Validation test script

### Files Modified
1. `production/true_holdout_test_100_optimized.py` - Fixed label creation + use new ranker
2. `src/modeling/rankers/__init__.py` - Export new classes

## Technical Details

### Position Feature Extraction Architecture
Each imputation method has a specific feature structure:

```python
'amplitude': {
    'amplitudes': (0, 39),           # Position-specific
    'probabilities': (39, 78),        # Position-specific
    'interference': (78, 174),        # Cross-position
    'entanglement': (174, 178),       # Event-level
    'proximity': (178, 377)           # Position-specific (199 features)
}
```

For position P, we extract:
- `amplitude[P]` from index P-1 in amplitudes slice
- `probability[P]` from index P-1 in probabilities slice
- All 199 proximity features for position P (min_distance, tunneling, density_windows)
- Event-level features (interference patterns, entanglement measures)

### Label Creation Fix
```python
# BEFORE (WRONG):
for q_idx in range(5):
    train_df[f'q_{q_idx+1}'] = 0  # ALL ZEROS!

# AFTER (CORRECT):
for idx in range(len(train_data)):
    winning_positions = [i for i in range(1, 40) if train_data.iloc[idx][f'QV_{i}'] == 1]
    for q_idx in range(5):
        if q_idx < len(winning_positions):
            train_df.loc[idx, f'q_{q_idx+1}'] = winning_positions[q_idx]
```

## Impact

### Models Now Learn Properly
- Feature importances are meaningful (non-zero)
- Position-specific quantum features are top-ranked
- Each imputation method captures different patterns

### Ensemble Voting Now Meaningful
- 4 diverse models with different strengths
- Majority voting will improve robustness
- Meta-learning/stacking becomes viable

### Production Ready
- Ready for RunPod 100-event TRUE holdout test
- Proper temporal isolation maintained
- Position-specific quantum patterns correctly utilized

## Next Steps
1. Run 5-event validation test
2. Package for RunPod deployment (16 vCPU, 32GB RAM)
3. Run full 100-event TRUE holdout test
4. Analyze ensemble performance vs individual models

---
**Author**: BMad Dev Agent (James)
**Date**: 2025-10-28
**Session**: Critical bug discovery and fix
