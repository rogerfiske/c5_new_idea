#!/bin/bash
#
# RunPod Holdout Test v4.0 - Single Command Execution
#
# Usage:
#   bash run_holdout_test.sh --events 100                    # No metrics
#   bash run_holdout_test.sh --events 100 --collect-metrics  # With metrics
#

# Default values
NUM_EVENTS=100
COLLECT_METRICS=""
OUTPUT_DIR="output/reports/holdout_100"

# Parse arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --events)
            NUM_EVENTS="$2"
            shift 2
            ;;
        --collect-metrics)
            COLLECT_METRICS="--collect-metrics"
            shift
            ;;
        --output-dir)
            OUTPUT_DIR="$2"
            shift 2
            ;;
        *)
            echo "Unknown option: $1"
            echo "Usage: bash run_holdout_test.sh --events N [--collect-metrics] [--output-dir DIR]"
            exit 1
            ;;
    esac
done

echo "================================================================================"
echo "RunPod Holdout Test v4.0 - Pre-Imputed Architecture"
echo "================================================================================"
echo "Events to test: $NUM_EVENTS"
echo "Collect metrics: $([ -n "$COLLECT_METRICS" ] && echo 'YES' || echo 'NO')"
echo "Output directory: $OUTPUT_DIR"
echo "================================================================================"
echo

# Ensure output directory exists
mkdir -p "$OUTPUT_DIR"

# Run test
python production/true_holdout_test_v4.0_PRE_IMPUTED.py \
    --num-events $NUM_EVENTS \
    --output-dir "$OUTPUT_DIR" \
    $COLLECT_METRICS

echo
echo "================================================================================"
echo "TEST COMPLETE"
echo "================================================================================"
echo "Results saved to: $OUTPUT_DIR/checkpoint.json"
echo
echo "To view results:"
echo "  cat $OUTPUT_DIR/checkpoint.json | python -m json.tool"
echo
