# RunPod Setup and Execution Guide - v4.0

## Pre-Flight Checklist

Before starting, verify:
- [ ] GPU pod with Python 3.8+ installed
- [ ] At least 16GB RAM available
- [ ] At least 10GB disk space free
- [ ] Internet access for pip install

## Step-by-Step Setup

### 1. Upload Package to RunPod

Option A: Upload via web interface
- Open RunPod web terminal
- Click "Upload Files"
- Select `runpod_holdout_v4.0.tar.gz`

Option B: Download from URL
```bash
wget https://your-url/runpod_holdout_v4.0.tar.gz
```

### 2. Extract Package

```bash
tar -xzf runpod_holdout_v4.0.tar.gz
cd runpod_holdout_v4.0
```

Verify structure:
```bash
ls -la
# Should see: data/ src/ production/ output/ requirements.txt README.md
```

### 3. Install Dependencies

```bash
pip install -r requirements.txt
```

Expected output:
```
Successfully installed numpy-1.24.3 pandas-2.0.3 scikit-learn-1.3.0 lightgbm-4.0.0 ...
```

### 4. Verify Setup

Quick verification test (1 event, ~5 min):
```bash
bash run_holdout_test.sh --events 1
```

Check results:
```bash
ls -lh output/reports/holdout_100/checkpoint.json
# Should show file with data
```

### 5. Run Full Test

**100-event test without metrics** (~8 hours):
```bash
nohup bash run_holdout_test.sh --events 100 > output/logs/run.log 2>&1 &
```

**With metrics** (~10-12 hours):
```bash
nohup bash run_holdout_test.sh --events 100 --collect-metrics > output/logs/run.log 2>&1 &
```

Monitor progress:
```bash
tail -f output/logs/run.log
```

### 6. Monitor Progress

Check completed events:
```bash
python -c "import json; d=json.load(open('output/reports/holdout_100/checkpoint.json')); print(f'Completed: {d[\"num_events_completed\"]}/100')"
```

### 7. Download Results

After completion:
```bash
# Create results archive
tar -czf results_v4.0.tar.gz output/reports/holdout_100/

# Download via RunPod web interface
# Or use scp if SSH enabled
```

## Troubleshooting

### "ModuleNotFoundError: No module named 'src'"
**Solution**: Make sure you're in the `runpod_holdout_v4.0` directory
```bash
pwd  # Should end with /runpod_holdout_v4.0
```

### "FileNotFoundError: data/imputed/amplitude_imputed.csv"
**Solution**: Verify data files extracted correctly
```bash
ls -lh data/imputed/
# Should show 4 CSV files (amplitude, angle, graph, density)
```

### "Process killed" or "Out of memory"
**Solution**: Reduce batch size or use GPU pod with more RAM

### Test taking too long
**Expected**: 100 events = ~8-10 hours (normal!)
- Each event: ~5 minutes
- Models train in parallel (4 models simultaneously)

## Advanced Options

### Custom Output Directory
```bash
bash run_holdout_test.sh --events 50 --output-dir output/reports/test_50
```

### Resume from Checkpoint
Script automatically resumes if checkpoint.json exists (NOT YET IMPLEMENTED in v4.0)

### Collect Selective Metrics
Modify script to collect metrics every 10th event (reduces overhead)
```python
# In true_holdout_test_v4.0_PRE_IMPUTED.py, line 344:
collect_metrics_for_event = (event_index % 10 == 0)  # Every 10th event
```

## Results Structure

After completion, `output/reports/holdout_100/` contains:

```
checkpoint.json                    # Main results (ALWAYS HERE!)
├── last_completed_event
├── num_events_completed
├── timestamp
└── evaluations: [
      {
        event_id: 11490,
        actual_winners: [3, 15, 20, 35, 39],
        models: {
          amplitude: { predictions: [...], hits: 4, recall_at_k: 0.8, wrong_count: 1 },
          angle_encoding: { ... },
          graph_cycle: { ... },
          density_matrix: { ... }
        }
      },
      ...
    ]
```

## Contact

Issues? Document in RUNPOD_ISSUES.md in project root.
