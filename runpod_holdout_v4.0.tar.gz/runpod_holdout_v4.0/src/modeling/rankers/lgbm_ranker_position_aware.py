"""
Position-Aware LightGBM Ranker

This extends the standard LGBMRanker to properly extract position-specific features
from imputation methods, fixing the bug where all positions got identical event-level features.

Author: BMad Dev Agent (James)
Date: 2025-10-28
"""

import numpy as np
import pandas as pd
from typing import Dict, Optional, Any, Tuple
import logging
from .lgbm_ranker import LGBMRanker
from .position_feature_extractor import PositionFeatureExtractor

logger = logging.getLogger(__name__)


class LGBMRankerPositionAware(LGBMRanker):
    """
    LightGBM Ranker with proper position-specific feature extraction.

    This fixes the critical bug where all 4 imputation models gave identical predictions
    because they were using the same event-level features for all 39 positions.

    Now each position gets features specific to that position:
    - Amplitude: position amplitude, probability, proximity
    - Angle: position angle, sin/cos, proximity
    - Graph: DFT/graph context + position proximity
    - Density: density context + position proximity
    """

    def __init__(
        self,
        params: Optional[Dict[str, Any]] = None,
        track_time: bool = True,
        imputation_method: str = None
    ):
        """
        Initialize position-aware LightGBM ranker.

        Args:
            params: LightGBM hyperparameters
            track_time: Whether to track training time
            imputation_method: REQUIRED - one of ['amplitude', 'angle_encoding', 'graph_cycle', 'density_matrix']
        """
        super().__init__(params=params, track_time=track_time)

        if imputation_method is None:
            raise ValueError(
                "imputation_method is required for LGBMRankerPositionAware. "
                "Use one of: ['amplitude', 'angle_encoding', 'graph_cycle', 'density_matrix']"
            )

        self.imputation_method = imputation_method
        self.position_extractor = PositionFeatureExtractor(imputation_method)

    def _transform_to_ranking_format(
        self, X: pd.DataFrame, active_positions_list: list
    ) -> Tuple[pd.DataFrame, np.ndarray, np.ndarray]:
        """
        Override to add logging of feature columns in DataFrame.
        """
        X_rank, y_rank, groups = super()._transform_to_ranking_format(X, active_positions_list)
        return X_rank, y_rank, groups

    def _create_position_features(self, position: int, event_row: pd.Series) -> Dict[str, float]:
        """
        Create position-specific features using PositionFeatureExtractor.

        This OVERRIDES the parent class method to properly extract position-specific
        features from the imputed event-level feature vector.

        Args:
            position: Position index (1-39)
            event_row: Event features from imputed data

        Returns:
            Dictionary of features for this position
        """
        features = {}

        # Add basic engineered features (same as parent class)
        features['position_frequency'] = self.position_frequencies_.get(position, 1e-6)
        features['position_id'] = position

        # Circular distance features
        for ref_pos in [1, 10, 20, 30]:
            dist = self._circular_distance(position, ref_pos, n_positions=39)
            features[f'circ_dist_{ref_pos}'] = dist

        # Ring quadrant
        features['ring_quadrant'] = (position - 1) // 10

        # === KEY FIX: Extract position-specific imputed features ===
        # Get all imputed feature columns (exclude targets and metadata)
        target_cols = ['q_1', 'q_2', 'q_3', 'q_4', 'q_5']
        qv_cols = [f'QV_{i}' for i in range(1, 40)]
        exclude_cols = set(target_cols + qv_cols + ['event-ID'])

        # Get feature vector (feat_0, feat_1, ...)
        feature_cols = [col for col in event_row.index if col.startswith('feat_')]
        if feature_cols:
            event_features = event_row[feature_cols].values

            # Extract position-specific features using PositionFeatureExtractor
            position_specific = self.position_extractor.extract_position_features(
                event_features, position
            )

            # Add to feature dict
            features.update(position_specific)
        else:
            # Fallback: If no feat_* columns, use parent class behavior
            # Add all remaining columns as features (but NOT feat_* columns)
            for col in event_row.index:
                if col not in exclude_cols and col not in features and not col.startswith('feat_'):
                    features[col] = event_row[col]

        return features

    def predict_position_scores(self, X: pd.DataFrame) -> np.ndarray:
        """
        Predict scores for all 39 positions for each event.

        Args:
            X: Test features (n_events, n_features)

        Returns:
            Position scores (n_events, 39) - scores for each position
        """
        # Create ranking format data for all 39 positions
        X_rank_list = []

        for idx in range(len(X)):
            event_row = X.iloc[idx]

            # Create features for all 39 positions
            for position in range(1, 40):
                position_features = self._create_position_features(position, event_row)
                X_rank_list.append(position_features)

        # Convert to DataFrame
        X_rank = pd.DataFrame(X_rank_list)

        # Ensure all feature names match training
        for col in self.feature_names_:
            if col not in X_rank.columns:
                X_rank[col] = 0.0

        X_rank = X_rank[self.feature_names_]

        # Predict scores
        scores = self.model_.predict(X_rank)

        # Reshape to (n_events, 39)
        n_events = len(X)
        scores_reshaped = scores.reshape(n_events, 39)

        return scores_reshaped
