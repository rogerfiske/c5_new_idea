"""
Position-Specific Feature Extractor

This module extracts position-specific features from imputed event-level feature vectors.
Each imputation method creates a flat feature vector per event, but for ranking we need
features specific to each of the 39 candidate positions.

Author: BMad Dev Agent (James)
Date: 2025-10-28
"""

import numpy as np
import pandas as pd
from typing import Dict, Tuple


class PositionFeatureExtractor:
    """
    Extracts position-specific features from imputed event-level feature vectors.

    Each imputation method has a different feature structure:
    - Amplitude: position amplitudes, probabilities, interference, entanglement, proximity
    - Angle: position angles, sin/cos, aggregates, proximity
    - Graph/Cycle: DFT harmonics (event-level), graph features (event-level), proximity
    - Density: density matrix elements, eigenvalues, purity, proximity

    All methods include 199 proximity features at the end (position-specific).
    """

    def __init__(self, method_name: str):
        """
        Initialize feature extractor for a specific imputation method.

        Args:
            method_name: One of ['amplitude', 'angle_encoding', 'graph_cycle', 'density_matrix']
        """
        self.method_name = method_name

        # Define feature structure for each method
        # Format: (position_specific_start, position_specific_end, num_positions, proximity_start)
        self.feature_structures = {
            'amplitude': {
                'amplitudes': (0, 39),           # Position-specific amplitudes
                'probabilities': (39, 78),        # Position-specific probabilities
                'interference': (78, 174),        # Cross-position (not used per-position)
                'entanglement': (174, 178),       # Event-level aggregates
                'proximity': (178, 377)           # Position-specific proximity (199 features)
            },
            'angle_encoding': {
                'angles': (0, 39),                # Position-specific angles
                'sin_cos': (39, 117),             # Position-specific sin/cos (39×2)
                'aggregates': (117, 123),         # Event-level aggregates
                'proximity': (123, 322)           # Position-specific proximity (199 features)
            },
            'graph_cycle': {
                'dft_features': (0, 57),          # Event-level DFT (magnitude + phase + aggregates)
                'graph_features': (57, 78),       # Event-level graph features
                'proximity': (78, 277)            # Position-specific proximity (199 features)
            },
            'density_matrix': {
                'density_elements': (0, 60),      # Event-level density matrix elements
                'proximity': (60, 259)            # Position-specific proximity (199 features)
            }
        }

        if method_name not in self.feature_structures:
            raise ValueError(
                f"Unknown imputation method: {method_name}. "
                f"Must be one of {list(self.feature_structures.keys())}"
            )

    def extract_position_features(
        self,
        event_features: np.ndarray,
        position: int
    ) -> Dict[str, float]:
        """
        Extract features relevant to a specific position from event-level features.

        Args:
            event_features: Flat feature vector for one event (e.g., shape (377,) for amplitude)
            position: Position index (1-39)

        Returns:
            Dictionary of features for this position
        """
        features = {}
        structure = self.feature_structures[self.method_name]
        pos_idx = position - 1  # Convert to 0-indexed

        if self.method_name == 'amplitude':
            # Extract position-specific features
            features['amplitude'] = event_features[structure['amplitudes'][0] + pos_idx]
            features['probability'] = event_features[structure['probabilities'][0] + pos_idx]

            # Add interference features involving this position
            # For now, we'll add a summary: how much this position interferes with others
            interference_slice = event_features[structure['interference'][0]:structure['interference'][1]]
            features['interference_strength'] = float(np.abs(interference_slice).sum())
            features['interference_mean'] = float(np.mean(np.abs(interference_slice)))

            # Add event-level entanglement features (same for all positions)
            entanglement_features = event_features[structure['entanglement'][0]:structure['entanglement'][1]]
            for i, val in enumerate(entanglement_features):
                features[f'entanglement_{i}'] = float(val)

            # Extract position-specific proximity features
            proximity_features = self._extract_proximity_features(
                event_features, structure['proximity'], pos_idx
            )
            features.update(proximity_features)

        elif self.method_name == 'angle_encoding':
            # Extract position-specific features
            features['angle'] = event_features[structure['angles'][0] + pos_idx]
            features['sin'] = event_features[structure['sin_cos'][0] + pos_idx]
            features['cos'] = event_features[structure['sin_cos'][0] + 39 + pos_idx]

            # Add event-level aggregate features
            aggregate_features = event_features[structure['aggregates'][0]:structure['aggregates'][1]]
            for i, val in enumerate(aggregate_features):
                features[f'aggregate_{i}'] = float(val)

            # Extract position-specific proximity features
            proximity_features = self._extract_proximity_features(
                event_features, structure['proximity'], pos_idx
            )
            features.update(proximity_features)

        elif self.method_name == 'graph_cycle':
            # For graph/cycle, most features are event-level (DFT, graph features)
            # We include them all as context since they describe global structure

            # Add all event-level DFT features
            dft_features = event_features[structure['dft_features'][0]:structure['dft_features'][1]]
            for i, val in enumerate(dft_features):
                features[f'dft_{i}'] = float(val)

            # Add all event-level graph features
            graph_features_slice = event_features[structure['graph_features'][0]:structure['graph_features'][1]]
            for i, val in enumerate(graph_features_slice):
                features[f'graph_{i}'] = float(val)

            # Extract position-specific proximity features
            proximity_features = self._extract_proximity_features(
                event_features, structure['proximity'], pos_idx
            )
            features.update(proximity_features)

        elif self.method_name == 'density_matrix':
            # For density matrix, most features are event-level
            # We include them as context

            # Add all event-level density features
            density_features = event_features[structure['density_elements'][0]:structure['density_elements'][1]]
            for i, val in enumerate(density_features):
                features[f'density_{i}'] = float(val)

            # Extract position-specific proximity features
            proximity_features = self._extract_proximity_features(
                event_features, structure['proximity'], pos_idx
            )
            features.update(proximity_features)

        return features

    def _extract_proximity_features(
        self,
        event_features: np.ndarray,
        proximity_range: Tuple[int, int],
        pos_idx: int
    ) -> Dict[str, float]:
        """
        Extract position-specific proximity features.

        Proximity features have structure:
        - 39 min_distance features (one per position)
        - 39 tunneling features (one per position)
        - 39×3 density features (3 windows, one set per position)
        - Optional: 39 interference features

        Total: 195 or 234 features depending on interference inclusion

        Args:
            event_features: Full event feature vector
            proximity_range: (start, end) indices for proximity features
            pos_idx: Position index (0-indexed, 0-38)

        Returns:
            Dictionary of position-specific proximity features
        """
        proximity_features = {}

        start, end = proximity_range
        proximity_slice = event_features[start:end]
        num_proximity = len(proximity_slice)

        # Structure: 39 min_dist + 39 tunnel + 39×num_windows density [+ 39 interference if included]
        # Most common: 39 + 39 + 117 = 195 features
        # With interference: 39 + 39 + 117 + 39 = 234 features

        # Extract this position's proximity features
        if num_proximity >= 195:
            proximity_features['min_distance'] = float(proximity_slice[pos_idx])
            proximity_features['tunneling'] = float(proximity_slice[39 + pos_idx])

            # Density features (3 windows: 3, 5, 7)
            for window_idx in range(3):
                proximity_features[f'density_window_{window_idx}'] = float(
                    proximity_slice[78 + window_idx * 39 + pos_idx]
                )

            # Interference if present (234 total features means it's included)
            if num_proximity >= 234:
                proximity_features['interference'] = float(proximity_slice[195 + pos_idx])
        else:
            # Handle older versions or different configurations
            # Just take what's available
            proximity_features['proximity_aggregate'] = float(np.mean(proximity_slice))

        return proximity_features

    def get_feature_names(self) -> list:
        """
        Get list of feature names that will be extracted for each position.

        Returns:
            List of feature name strings
        """
        # Extract from a dummy event to get the feature names
        dummy_features = np.zeros(self._get_expected_feature_count())
        extracted = self.extract_position_features(dummy_features, position=1)
        return list(extracted.keys())

    def _get_expected_feature_count(self) -> int:
        """Get expected number of features for this imputation method."""
        expected_counts = {
            'amplitude': 377,
            'angle_encoding': 322,
            'graph_cycle': 277,
            'density_matrix': 259
        }
        return expected_counts[self.method_name]
