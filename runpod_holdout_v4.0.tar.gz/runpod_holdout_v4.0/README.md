# RunPod Holdout Test v4.0 - Pre-Imputed Architecture

## Critical Fix: Eliminates Data Leakage

Previous versions (v2.0) performed on-the-fly imputation using test event's QV values, causing data leakage and impossible 100% perfect results.

**v4.0 uses PRE-COMPUTED imputed datasets** - no access to test event answers during feature creation.

## Quick Start (3 Steps)

### 1. Install Dependencies (~30 seconds)
```bash
pip install -r requirements.txt
```

### 2. Run Holdout Test

**100 events without metrics** (~8 hours):
```bash
bash run_holdout_test.sh --events 100
```

**100 events WITH detailed metrics** (~10-12 hours):
```bash
bash run_holdout_test.sh --events 100 --collect-metrics
```

**Quick test (10 events)** (~48 minutes):
```bash
bash run_holdout_test.sh --events 10
```

### 3. View Results

Results are ALWAYS saved to: `output/reports/holdout_100/checkpoint.json`

```bash
# Pretty-print results
cat output/reports/holdout_100/checkpoint.json | python -m json.tool

# View summary
python production/analyze_results.py output/reports/holdout_100/checkpoint.json
```

## What's Inside

- **data/raw/**: Original c5_Matrix.csv (11589 events)
- **data/imputed/**: Pre-computed imputed datasets (4 methods × 11589 events)
- **src/**: Source code (imputation, modeling, evaluation)
- **production/**: Test scripts
- **output/**: Results directory (pre-created, no path errors!)

## Architecture: Pre-Imputed vs On-the-Fly

### Previous (WRONG - Data Leakage):
```python
# Load raw data
test_data = raw[event==11490]  # Contains QV values (the answer!)

# Impute on-the-fly using test answers
test_features = imputer.transform(test_data)  # LEAKAGE!
```

### Current (CORRECT - Pre-Imputed):
```python
# Load PRE-COMPUTED features
imputed_data = pd.read_csv('data/imputed/amplitude_imputed.csv')

# Split by event-ID
train = imputed_data[imputed_data['event-ID'] < 11490]
test = imputed_data[imputed_data['event-ID'] == 11490]

# Features created BEFORE test, no access to test QV values
```

## Expected Results

With data leakage fixed, expect **realistic performance**:

- **Recall@20**: 60-80% per model (NOT 100%!)
- **Wrong count distribution**: Mix of 0-5 wrong across events
- **Model differences**: Different performance across 4 methods

## Timing

- **Per event**: ~5 minutes (4 models trained in parallel)
- **100 events**: ~8 hours without metrics, ~10-12 hours with metrics
- **Time breakdown**:
  - Data loading: <1s
  - Model training: ~2.5 min (87% of time)
  - Prediction: <1s
  - Metrics collection (if enabled): ~1-2 min

## Support

Questions? Check SETUP_AND_RUN.md for detailed instructions.
