"""
Analyze RunPod 100-Event Holdout Test - Wrong Count Distribution

Generates a summary showing how many events had 0-5 wrong predictions
for each quantum imputation method and the ensemble.

Format matches the Gann Phase 2D model summary style.

Author: James (Dev Agent)
Date: 2025-10-30
"""

import json
from pathlib import Path
from typing import Dict, List


def calculate_wrong_count(predicted: List[int], actual: List[int]) -> int:
    """
    Calculate how many actual values are NOT in the predicted top-20.

    Args:
        predicted: Top-20 predicted positions
        actual: 5 actual winning positions

    Returns:
        Number of actual winners NOT in top-20 (0-5)
    """
    predicted_set = set(predicted)
    actual_set = set(actual)

    # Count how many actual winners are NOT in predicted
    wrong_count = len(actual_set - predicted_set)

    return wrong_count


def analyze_model_performance(evaluations: List[Dict], model_name: str) -> Dict[int, int]:
    """
    Analyze wrong count distribution for a specific model.

    Args:
        evaluations: List of evaluation dictionaries from checkpoint
        model_name: Name of model ('amplitude', 'angle_encoding', etc.)

    Returns:
        Dictionary mapping wrong_count (0-5) to number of events
    """
    wrong_count_dist = {0: 0, 1: 0, 2: 0, 3: 0, 4: 0, 5: 0}

    for event in evaluations:
        # The checkpoint already has wrong_count calculated
        wrong_count = event[model_name]['wrong_count']
        wrong_count_dist[wrong_count] += 1

    return wrong_count_dist


def print_holdout_summary(model_display_name: str, wrong_count_dist: Dict[int, int], total_events: int):
    """
    Print holdout test summary in the requested format.

    Args:
        model_display_name: Display name for the model
        wrong_count_dist: Distribution of wrong counts
        total_events: Total number of events tested
    """
    print(f"\nHOLDOUT TEST SUMMARY - {total_events} Events")
    print(f"{model_display_name}")
    print("  " + "-" * 60)

    descriptions = {
        0: "All 5 actual values in top-20",
        1: "4 of 5 actual values in top-20",
        2: "3 of 5 actual values in top-20",
        3: "2 of 5 actual values in top-20",
        4: "1 of 5 actual values in top-20",
        5: "0 of 5 actual values in top-20"
    }

    for wrong_count in range(6):
        count = wrong_count_dist[wrong_count]
        percentage = (count / total_events) * 100
        desc = descriptions[wrong_count]

        print(f"  {wrong_count} wrong: {count:3d} events ({percentage:5.2f}%)  <-- {desc}")


def main():
    """Main execution: Parse checkpoint and generate summaries."""
    # Load checkpoint
    checkpoint_path = Path(__file__).parent / 'checkpoint.json'

    print("="*80)
    print("RUNPOD 100-EVENT HOLDOUT TEST - WRONG COUNT ANALYSIS")
    print("="*80)
    print(f"\nLoading checkpoint: {checkpoint_path}")

    with open(checkpoint_path, 'r') as f:
        data = json.load(f)

    evaluations = data['evaluations']
    total_events = len(evaluations)

    print(f"Total events analyzed: {total_events}")
    print(f"Event range: {evaluations[0]['event_id']} - {evaluations[-1]['event_id']}")
    print(f"Test date: {data['timestamp'][:10]}")

    # Model configurations
    models = [
        ('amplitude', 'Amplitude Embedding (Quantum Probability) Model'),
        ('angle_encoding', 'Angle Encoding (Bloch Sphere) Model'),
        ('graph_cycle', 'Graph/Cycle Encoding (DFT) Model'),
        ('density_matrix', 'Density Matrix (Entropy) Model'),
        ('ensemble', 'Ensemble (All 4 Methods Combined)')
    ]

    # Analyze each model
    results = {}
    for model_key, model_display in models:
        wrong_count_dist = analyze_model_performance(evaluations, model_key)
        results[model_key] = wrong_count_dist
        print_holdout_summary(model_display, wrong_count_dist, total_events)

    # Summary statistics
    print("\n" + "="*80)
    print("COMPARATIVE SUMMARY")
    print("="*80)
    print(f"\n{'Model':<35} {'Perfect (0 wrong)':<20} {'Recall@20'}")
    print("-"*80)

    for model_key, model_display in models:
        perfect_count = results[model_key][0]
        perfect_pct = (perfect_count / total_events) * 100

        # Calculate recall@20 (percentage of actual winners captured)
        total_possible = total_events * 5  # 5 winners per event
        total_wrong = sum(count * wrong_count
                         for wrong_count, count in results[model_key].items())
        total_correct = total_possible - total_wrong
        recall = (total_correct / total_possible) * 100

        model_short = model_display.split('(')[0].strip()
        print(f"{model_short:<35} {perfect_count:3d} events ({perfect_pct:5.2f}%)  {recall:6.2f}%")

    # Save results to JSON
    output_path = Path(__file__).parent / 'wrong_count_analysis.json'
    with open(output_path, 'w') as f:
        json.dump({
            'metadata': {
                'test_date': data['timestamp'],
                'total_events': total_events,
                'event_range': [evaluations[0]['event_id'], evaluations[-1]['event_id']]
            },
            'wrong_count_distributions': results
        }, f, indent=2)

    print(f"\n\nDetailed results saved to: {output_path}")
    print("="*80)


if __name__ == '__main__':
    main()
